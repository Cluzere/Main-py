# File uji CLOUZER - jangan dieksekusi, cukup dibaca.
def total_tanaman(utara, selatan):
    return utara + selatan

print(total_tanaman(24, 18))  # hasil yang diharapkan: 42
