README UJI
File ini dipasangkan dengan 03_hitung_total.py.
Fungsi utama menghitung jumlah tanaman dari dua lokasi.
