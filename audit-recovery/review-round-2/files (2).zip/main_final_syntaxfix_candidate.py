import os
import io
import re
import json
import time
import logging
import base64
import random
import urllib.parse
import ipaddress
import socket
import asyncio
import math
import copy
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from collections import defaultdict, OrderedDict, deque
from typing import NamedTuple
import discord
from discord import app_commands
from discord.ext import commands
import aiohttp
from PIL import Image
from dotenv import load_dotenv

try:
    import pymupdf as fitz  # PyMuPDF untuk baca teks & render halaman PDF
except ImportError:
    fitz = None

try:
    import docx  # python-docx untuk baca file .docx
except ImportError:
    docx = None

try:
    from pptx import Presentation  # python-pptx untuk baca file .pptx
except ImportError:
    Presentation = None

try:
    import openpyxl  # openpyxl untuk baca file .xlsx
except ImportError:
    openpyxl = None

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
XINGCHI_API_KEY = os.getenv("XINGCHI_API_KEY")
XINGCHI_BASE_URL = os.getenv("XINGCHI_BASE_URL", "https://api.xingchiapi.com/v1").rstrip("/")
_provider_url = urllib.parse.urlsplit(XINGCHI_BASE_URL)
if (not _provider_url.hostname or _provider_url.username or _provider_url.password
        or (_provider_url.scheme.lower() != "https" and os.getenv("ALLOW_INSECURE_BASE_URL", "").strip().lower() not in {"1", "true", "yes", "on", "y"})):
    raise RuntimeError("XINGCHI_BASE_URL wajib berupa URL valid tanpa kredensial di URL; HTTPS diwajibkan kecuali override lokal diaktifkan.")
XINGCHI_MODEL = os.getenv("XINGCHI_MODEL", "gpt-6.1-sol")
XINGCHI_AUDIO_MODEL = os.getenv("XINGCHI_AUDIO_MODEL", "whisper-1").strip()

CF_COOLDOWN_SECONDS = float(os.getenv("CF_COOLDOWN_SECONDS", "45"))
IMAGE_CONTEXT_TTL_SECONDS = float(os.getenv("IMAGE_CONTEXT_TTL_SECONDS", "1800"))
IMAGE_CONTEXT_MAX_ENTRIES = int(os.getenv("IMAGE_CONTEXT_MAX_ENTRIES", "30"))
MAX_OUTPUT_IMAGE_BYTES = int(os.getenv("MAX_OUTPUT_IMAGE_BYTES", str(12 * 1024 * 1024)))
MAX_IMAGE_PIXELS = int(os.getenv("MAX_IMAGE_PIXELS", str(25_000_000)))
DISCORD_MSG_CHUNK_LIMIT = min(1990, max(500, int(os.getenv("DISCORD_MSG_CHUNK_LIMIT", "1900"))))
MEMORY_PROMPT_MAX_LEN = int(os.getenv("MEMORY_PROMPT_MAX_LEN", "160"))
MAX_VISION_IMAGES_PER_TURN = 5
# Defensive limits for ZIP-based office/e-book formats. These cap decompressed
# work, not just the uploaded compressed size.
ZIP_MAX_ENTRIES = 2000
ZIP_MAX_TOTAL_UNCOMPRESSED = 100 * 1024 * 1024
ZIP_MAX_ENTRY_UNCOMPRESSED = 25 * 1024 * 1024
ZIP_MAX_COMPRESSION_RATIO = 200

# ---------------------------------------------------------------------------
# Batas sumber daya & keamanan (patch security-hardening-2026-11).
# Semua nilai opsional: kalau tidak diisi di environment, default di bawah dipakai.
# ---------------------------------------------------------------------------
def _env_int(name: str, default: int, minimum: int = 0) -> int:
    try:
        return max(minimum, int(str(os.getenv(name, default)).strip()))
    except (TypeError, ValueError):
        return default


def _env_float(name: str, default: float, minimum: float = 0.0) -> float:
    try:
        return max(minimum, float(str(os.getenv(name, default)).strip()))
    except (TypeError, ValueError):
        return default


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on", "y"}


def _env_id_set(name: str) -> frozenset[int]:
    ids: set[int] = set()
    for part in re.split(r"[\s,;]+", os.getenv(name, "") or ""):
        if part.isdigit():
            ids.add(int(part))
    return frozenset(ids)


# Lampiran: jumlah, total ukuran, dan konkurensi pembacaan ke RAM.
MAX_ATTACHMENTS_PER_MESSAGE = _env_int("MAX_ATTACHMENTS_PER_MESSAGE", 4, minimum=1)
MAX_ATTACHMENT_TOTAL_BYTES = _env_int("MAX_ATTACHMENT_TOTAL_MB", 40, minimum=1) * 1024 * 1024
MAX_CONCURRENT_ATTACHMENTS = _env_int("MAX_CONCURRENT_ATTACHMENTS", 2, minimum=1)
ATTACHMENT_QUEUE_TIMEOUT_SECONDS = _env_float("ATTACHMENT_QUEUE_TIMEOUT_SECONDS", 45.0, minimum=1.0)
MAX_TEXT_FILE_CHARS = _env_int("MAX_TEXT_FILE_CHARS", 60_000, minimum=1_000)

# Pemakaian API: panggilan Xingchi paralel + anggaran panjang prompt riwayat.
MAX_CONCURRENT_AI_CALLS = _env_int("MAX_CONCURRENT_AI_CALLS", 4, minimum=1)
PROMPT_HISTORY_MAX_CHARS = _env_int("PROMPT_HISTORY_MAX_CHARS", 240_000, minimum=20_000)

# Deteksi secret: file dengan >= N secret berbeda ditolak total (bukan hanya disensor).
SECRET_BLOCK_THRESHOLD = _env_int("SECRET_BLOCK_THRESHOLD", 5, minimum=1)

# Rate limit per pengguna. Format override per kategori:
#   RATE_<KATEGORI>_COOLDOWN (detik jeda minimum), RATE_<KATEGORI>_MAX, RATE_<KATEGORI>_WINDOW (detik)
RATE_LIMIT_ENABLED = _env_bool("RATE_LIMIT_ENABLED", True)
RATE_LIMIT_EXEMPT_USER_IDS = _env_id_set("RATE_LIMIT_EXEMPT_USER_IDS")
RATE_DAILY_LIMIT_PER_USER = _env_int("RATE_DAILY_LIMIT_PER_USER", 400, minimum=0)
DIAGNOSTIC_ADMIN_ONLY = _env_bool("DIAGNOSTIC_ADMIN_ONLY", False)

# Penyimpanan state tombol (Regenerate / DM) supaya tetap hidup setelah restart.
VIEW_STATE_FILE = os.path.join(BASE_DIR, "view_state.json")
VIEW_STATE_MAX_ENTRIES = _env_int("VIEW_STATE_MAX_ENTRIES", 2000, minimum=10)
VIEW_STATE_MAX_SNAPSHOTS = _env_int("VIEW_STATE_MAX_SNAPSHOTS", 100, minimum=1)
VIEW_STATE_LIVE_MEDIA = _env_int("VIEW_STATE_LIVE_MEDIA", 20, minimum=0)
VIEW_STATE_SNAPSHOT_CHARS = _env_int("VIEW_STATE_SNAPSHOT_CHARS", 48_000, minimum=2_000)
VIEW_STATE_RETENTION_SECONDS = _env_int("VIEW_STATE_RETENTION_DAYS", 14, minimum=1) * 86400

Image.MAX_IMAGE_PIXELS = MAX_IMAGE_PIXELS

TEXT_EDIT_NOTE = (
    "Catatan: untuk revisi teks atau huruf yang butuh presisi tinggi, "
    "lebih aman dirapikan manual di **Canva** atau **Photopea**."
)

DATA_URL_BASE64_RE = re.compile(r"data:[a-zA-Z0-9.+/-]+;base64,[A-Za-z0-9+/=]+")
LONG_BASE64_RE = re.compile(r"(?<![A-Za-z0-9+/=])[A-Za-z0-9+/=]{256,}(?![A-Za-z0-9+/=])")
EXPLICIT_RATIO_RE = re.compile(r"\b(16:9|9:16|4:3|3:4|3:2|2:3|4:5|5:4|21:9|1:1)\b", re.IGNORECASE)

ASPECT_RATIO_DIMENSIONS: dict[str, tuple[int, int]] = {
    "1:1": (1024, 1024),
    "16:9": (1024, 576),
    "9:16": (576, 1024),
    "4:3": (1024, 768),
    "3:4": (768, 1024),
    "3:2": (960, 640),
    "2:3": (640, 960),
    "4:5": (768, 960),
    "5:4": (960, 768),
    "21:9": (1024, 448),
}


class _SimpleHTMLTextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self._chunks: list[str] = []

    def handle_data(self, data: str):
        cleaned = re.sub(r"\s+", " ", data).strip()
        if cleaned:
            self._chunks.append(cleaned)

    def get_text(self) -> str:
        return "\n".join(self._chunks)


def normalize_cf_json_str(raw: str) -> str:
    s = (raw or "").strip()
    if not s:
        return ""
    if len(s) >= 2 and s[0] == "'" and s[-1] == "'":
        s = s[1:-1].strip()
    if '\\"' in s and not s.startswith("["):
        s = s.replace('\\"', '"')
    elif '\\"' in s and s.startswith("["):
        try:
            json.loads(s)
        except Exception:
            s = s.replace('\\"', '"')
    return s


def load_cf_accounts() -> list[dict[str, str]]:
    raw_json = normalize_cf_json_str(os.getenv("CF_ACCOUNTS_JSON", ""))
    if not raw_json:
        return []
    try:
        parsed = json.loads(raw_json)
    except Exception:
        return []
    if not isinstance(parsed, list):
        return []

    accounts: list[dict[str, str]] = []
    for idx, item in enumerate(parsed, start=1):
        if not isinstance(item, dict):
            continue
        acc_id = str(item.get("account_id", "")).strip()
        token = str(item.get("api_token", "")).strip()
        label = str(item.get("id") or f"Akun {idx}").strip()[:24]
        if acc_id and token:
            accounts.append({"id": acc_id, "token": token, "label": label})
    return accounts


CF_ACCOUNTS: list[dict[str, str]] = load_cf_accounts()

CF_IMAGE_MODEL = os.getenv("CF_IMAGE_MODEL", "@cf/leonardo/lucid-origin").strip()
CF_EDIT_MODEL = os.getenv("CF_EDIT_MODEL", "@cf/black-forest-labs/flux-2-klein-4b").strip()
CF_AUDIO_MODEL = os.getenv("CF_AUDIO_MODEL", "@cf/openai/whisper-large-v3-turbo").strip()

MEMORY_FILE = os.path.join(BASE_DIR, "memory.json")
MAX_MEMORY_FILE_BYTES = 20 * 1024 * 1024
MAX_RESPONSES_STREAM_BYTES = 20 * 1024 * 1024
MAX_RESPONSES_LINE_BYTES = 1024 * 1024
MAX_RECENT_MESSAGES = 10
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".gif")
AUDIO_EXTS = (".mp3", ".wav", ".ogg", ".m4a", ".flac", ".webm", ".aac", ".opus")

OFFICE_DOC_EXTS = {
    ".pdf", ".docx", ".pptx", ".xlsx", ".rtf",
    ".odt", ".ods", ".odp", ".epub",
    ".svg", ".eps", ".ai",
}

ALL_SUPPORTED_EXTS = {
    ".txt", ".py", ".js", ".ts", ".html", ".css", ".json", ".csv", ".md",
    ".xml", ".yml", ".yaml", ".ini", ".log", ".sql", ".sh",
    ".png", ".jpg", ".jpeg", ".webp", ".gif",
    ".mp3", ".wav", ".ogg", ".m4a", ".flac", ".webm", ".aac", ".opus",
} | OFFICE_DOC_EXTS

FULL_CONTENT_EXTS = {
    ".txt", ".py", ".js", ".ts", ".html", ".css", ".json", ".csv", ".md",
    ".xml", ".yml", ".yaml", ".ini", ".log", ".sql", ".sh",
} | OFFICE_DOC_EXTS

EDIT_INTENT_KEYWORDS = (
    "ganti", "ubah", "edit", "hapus", "tambah", "replace", "change",
    "recolor", "warnai", "mewarnai", "perbaiki", "koreksi", "retouch", "modif",
    "rasio", "aspect ratio", "perlebar", "perpanjang", "crop"
)

CREATE_INTENT_KEYWORDS = (
    "buatkan", "bikin", "buat", "lukis", "draw",
    "generate", "create", "render"
)

ANALYSIS_ONLY_KEYWORDS = (
    "jelaskan", "analisis", "analisa", "ringkas", "baca", "arti", "makna",
    "apa ini", "ini apa", "ada apa", "teks apa", "tulisan apa", "berapa", "kenapa",
    "mengapa", "bagaimana", "summarize", "explain", "read", "ocr", "transkrip",
    "menurut lu", "menurut kamu", "menurutmu", "terlihat apa", "kelihatan apa",
    "isinya apa", "maksudnya", "gimana maksud", "describe", "what is in"
)

BASE_SYSTEM_PROMPT = f"""Kamu adalah OpenAI GPT 6.1 SOL, asisten AI cerdas di Discord yang berjalan di Clouzer AI.

IDENTITAS MUTLAK (WAJIB DIPATUHI TANPA PENGECUALIAN):
- Nama & Model Resmi: OpenAI GPT 6.1 SOL (Model ID: {XINGCHI_MODEL})
- Penyedia API / Endpoint: xingchiapi.com (Xingchi API)
- Platform: Clouzer AI
- Pembuat / Pengembang: clouzerd

ATURAN MUTLAK PENELUSURAN WEB & JAWABAN (ANTI-DENIAL):
1. Kamu memiliki akses penelusuran web langsung (web_search). Kamu DILARANG KERAS menolak menjawab, DILARANG bilang "tidak punya akses kalender", "tidak punya akses web", atau "tidak bisa mengecek jadwal".
2. Jika pengguna menanyakan informasi apa pun yang bersifat terkini (jadwal bola, liga, skor, berita, cuaca, kurs, harga, event, tanggal, dll), gunakan tool web_search untuk mencari data terbarunya dan cantumkan selengkap-lengkapnya ke pengguna!
3. PEMBUATAN & PENGEDITAN GAMBAR (`generate_image`):
  - Jika pengguna meminta dibuatkan ilustrasi/foto baru dari nol, panggil `generate_image` dengan `use_attached_image: false` dan tulis `prompt` deskripsi visual detail berbahasa Inggris (panjang lega sekitar 300–900 karakter, aman dari konten NSFW/gore eksplisit).
  - Jika pengguna melampirkan gambar (atau merujuk gambar yang baru dikirim) lalu meminta MENGEDIT, MENGUBAH TEKS, MENGGANTI WARNA, MENGUBAH ASPEK RASIO, atau MEMODIFIKASI gambar tersebut, wajib panggil `generate_image` dengan `use_attached_image: true` dan tulis instruksi edit yang jelas serta presisi di `prompt`.
  - Isi parameter `aspect_ratio` sesuai permintaan pengguna (`1:1`, `16:9`, `9:16`, `4:3`, `3:4`, `3:2`, `2:3`, `4:5`, `5:4`, `21:9`), atau isi `auto` jika pengguna tidak menyebutkan rasio khusus (saat edit akan otomatis mengikuti rasio gambar asli, saat buat baru akan default ke `1:1`).
  - Jika pengguna hanya bertanya atau minta dijelaskan isi gambar/PDF/dokumen/presentasi/spreadsheet/desain/audio tanpa minta dibuatkan atau diedit gambarnya, JANGAN panggil `generate_image`.
  - Saat menyertai gambar dengan teks, sampaikan ringkasannya secara singkat dan santai tanpa menjelaskan proses penyusunan prompt.

ATURAN GAYA BAHASA:
- Gunakan bahasa gaul, santai, natural, dan tidak terlalu baku layaknya teman ngobrol yang pintar.
- Jangan pernah menyapa kosong jika user mengirim file, dokumen, slide, spreadsheet, file desain, atau audio; langsung baca teks atau transkripnya dan bahas isinya!"""


def format_memory_image_summary(engine_used: str, prompt: str, max_len: int = MEMORY_PROMPT_MAX_LEN) -> str:
    compact = re.sub(r"\s+", " ", (prompt or "").strip())
    if len(compact) > max_len:
        compact = compact[:max_len].rstrip() + "..."
    return f"[Gambar diproses ({engine_used}): {compact}]"


def normalize_aspect_ratio_str(raw: str | None) -> str | None:
    if not raw:
        return None
    cleaned = str(raw).strip().lower().replace("x", ":").replace("/", ":")
    if cleaned in ASPECT_RATIO_DIMENSIONS:
        return cleaned
    return None


def extract_aspect_ratio_from_text(text: str) -> str | None:
    if not text:
        return None
    m = EXPLICIT_RATIO_RE.search(text)
    if m:
        return m.group(1)
    low = text.lower()
    if any(k in low for k in ("widescreen", "layar lebar", "thumbnail youtube", "memanjang ke samping", "memanjang kesamping")):
        return "16:9"
    if any(k in low for k in ("ultrawide", "sinematik lebar")):
        return "21:9"
    if any(k in low for k in ("wallpaper hp", "story ig", "instagram story", "reels", "tiktok", "vertikal", "memanjang ke atas", "memanjang keatas")):
        return "9:16"
    return None


def resolve_image_dimensions(
    aspect_ratio_hint: str | None = None,
    prompt_text: str = "",
    source_images: list[str] | None = None,
) -> tuple[int, int, str]:
    normalized_hint = normalize_aspect_ratio_str(aspect_ratio_hint)
    if normalized_hint:
        w, h = ASPECT_RATIO_DIMENSIONS[normalized_hint]
        return w, h, normalized_hint

    detected = extract_aspect_ratio_from_text(prompt_text)
    if detected and detected in ASPECT_RATIO_DIMENSIONS:
        w, h = ASPECT_RATIO_DIMENSIONS[detected]
        return w, h, detected

    if source_images:
        try:
            _, b64_data = parse_data_url(source_images[0])
            raw_bytes = base64.b64decode(b64_data, validate=True)
            with Image.open(io.BytesIO(raw_bytes)) as img:
                orig_w, orig_h = img.size
            if orig_w > 0 and orig_h > 0:
                scale = 1024.0 / float(max(orig_w, orig_h))
                target_w = max(448, min(1024, int(round((orig_w * scale) / 16.0)) * 16))
                target_h = max(448, min(1024, int(round((orig_h * scale) / 16.0)) * 16))
                for label, (pw, ph) in ASPECT_RATIO_DIMENSIONS.items():
                    if abs((target_w / target_h) - (pw / ph)) < 0.03:
                        return pw, ph, label
                return target_w, target_h, f"{target_w}:{target_h}"
        except Exception:
            pass

    return 1024, 1024, "1:1"


def should_allow_image_tool(user_text: str, has_file_or_pdf: bool, has_image: bool) -> bool:
    low = (user_text or "").lower().strip()
    has_edit = any(k in low for k in EDIT_INTENT_KEYWORDS)
    has_create = any(k in low for k in CREATE_INTENT_KEYWORDS)
    has_analysis = any(k in low for k in ANALYSIS_ONLY_KEYWORDS)

    if has_edit or has_create:
        return True
    if has_file_or_pdf and not has_edit and not has_create:
        return False
    if has_image and has_analysis and not has_edit and not has_create:
        return False
    return True


def scrub_base64_text(text: str) -> str:
    if not text:
        return ""
    cleaned = DATA_URL_BASE64_RE.sub("[data-url-base64-dihapus]", text)
    cleaned = LONG_BASE64_RE.sub("[base64-dihapus]", cleaned)
    return cleaned


def scrub_nested_base64(value):
    if isinstance(value, str):
        return scrub_base64_text(value)
    if isinstance(value, list):
        return [scrub_nested_base64(item) for item in value]
    if isinstance(value, dict):
        return {str(k): scrub_nested_base64(v) for k, v in value.items()}
    return value


def clean_response_text(text: str) -> str:
    if not text:
        return ""
    text = re.sub(r"\ue200.*?\ue201", "", text, flags=re.DOTALL)
    text = re.sub(r"\ue200[^\ue201]*$", "", text)
    text = re.sub(r"[\ue200-\ue20f]", "", text)
    text = re.sub(r" +([.,!?;:])", r"\1", text)
    return text


def split_discord_chunks(text: str, limit: int = DISCORD_MSG_CHUNK_LIMIT) -> list[str]:
    safe_limit = min(1990, max(100, limit))
    text = text.strip()
    if len(text) <= safe_limit:
        return [text] if text else []

    chunks: list[str] = []
    remaining = text
    while len(remaining) > safe_limit:
        slice_part = remaining[:safe_limit]
        split_idx = slice_part.rfind("\n\n")
        if split_idx < safe_limit // 2:
            split_idx = slice_part.rfind("\n")
        if split_idx < safe_limit // 2:
            split_idx = slice_part.rfind(" ")
        if split_idx <= 0:
            split_idx = safe_limit

        chunks.append(remaining[:split_idx].rstrip())
        remaining = remaining[split_idx:].lstrip()

    if remaining:
        chunks.append(remaining)
    return chunks


def parse_data_url(data_url: str) -> tuple[str, str]:
    if data_url.startswith("data:") and ";base64," in data_url:
        header, b64_data = data_url.split(";base64,", 1)
        mime_type = header.replace("data:", "").strip() or "image/jpeg"
        return mime_type, b64_data
    return "image/jpeg", data_url


def check_responses_stream_limits(line_size: int, total_size: int) -> None:
    """Tolak baris/event atau total SSE Responses yang terlalu besar."""
    if line_size > MAX_RESPONSES_LINE_BYTES or total_size > MAX_RESPONSES_STREAM_BYTES:
        raise RuntimeError("Responses stream melewati batas ukuran keamanan.")


async def read_limited_stream(content, max_bytes: int, chunk_size: int = 65536) -> bytes:
    """Read an aiohttp stream with a hard memory ceiling."""
    if max_bytes < 0 or chunk_size <= 0:
        raise ValueError("Batas ukuran stream tidak valid")
    data = bytearray()
    async for chunk in content.iter_chunked(min(chunk_size, max(1, max_bytes + 1))):
        if len(data) + len(chunk) > max_bytes:
            raise ValueError(f"Respons melewati batas {max_bytes} byte")
        data.extend(chunk)
    return bytes(data)


def sanitize_image_prompt(prompt: str, max_len: int = 1500) -> str:
    cleaned = re.sub(r"\s+", " ", prompt).strip()
    return cleaned[:max_len].strip()


def validate_and_normalize_image_bytes(raw_bytes: bytes) -> tuple[bytes, str, str]:
    if not raw_bytes:
        raise RuntimeError("Data gambar kosong (0 byte)")
    if len(raw_bytes) > MAX_OUTPUT_IMAGE_BYTES:
        max_mb = MAX_OUTPUT_IMAGE_BYTES / (1024 * 1024)
        raise RuntimeError(f"Ukuran gambar melebihi batas maksimal ({max_mb:.0f} MB)")

    try:
        with Image.open(io.BytesIO(raw_bytes)) as probe:
            probe.verify()
            fmt = (probe.format or "").upper()
            width, height = probe.size
    except Exception as exc:
        raise RuntimeError(f"File gambar rusak atau format tidak dikenali: {exc}") from exc

    if width <= 0 or height <= 0 or (width * height) > MAX_IMAGE_PIXELS:
        raise RuntimeError(f"Dimensi gambar tidak valid ({width}x{height})")

    try:
        with Image.open(io.BytesIO(raw_bytes)) as img:
            img.load()
            if fmt in ("PNG", "JPEG", "WEBP", "GIF"):
                ext = "jpg" if fmt == "JPEG" else fmt.lower()
                mime = f"image/{'jpeg' if fmt == 'JPEG' else fmt.lower()}"
                out_buf = io.BytesIO()
                save_img = img.convert("RGB") if fmt == "JPEG" else img
                save_img.save(out_buf, format=fmt)
                normalized = out_buf.getvalue()
                if len(normalized) > MAX_OUTPUT_IMAGE_BYTES:
                    raise RuntimeError("Hasil normalisasi gambar melewati batas ukuran output.")
                return normalized, f"clouzer_image.{ext}", mime

            png_buf = io.BytesIO()
            img.convert("RGBA").save(png_buf, format="PNG")
            normalized = png_buf.getvalue()
            if len(normalized) > MAX_OUTPUT_IMAGE_BYTES:
                raise RuntimeError("Hasil normalisasi gambar melewati batas ukuran output.")
            return normalized, "clouzer_image.png", "image/png"
    except Exception as exc:
        raise RuntimeError(f"Gagal memverifikasi/menyiapkan gambar: {exc}") from exc


def build_failure_tool_continuation(calls: list[dict], reason: str) -> list[dict]:
    items: list[dict] = []
    for fc in calls:
        if not isinstance(fc, dict):
            continue
        call_id = str(fc.get("call_id") or "").strip()
        if call_id:
            items.append(fc)
            items.append({
                "type": "function_call_output",
                "call_id": call_id,
                "output": json.dumps({
                    "success": False,
                    "reason": reason,
                }, ensure_ascii=False),
            })
    return items


# =============================================================================
# LAPISAN KEAMANAN (patch security-hardening-2026-11)
#   1. Deteksi & sensor secret          -> scan_secrets / scrub_secrets
#   2. Kebijakan nama file sensitif     -> classify_sensitive_filename
#   3. Rate limiter per pengguna        -> RateLimiter
#   4. Penyimpanan state tombol         -> ViewStateStore
#   5. Redaksi log & teks error         -> SecretRedactionFilter / safe_exc_text
# Semua deteksi dirancang linear (tanpa nested quantifier) supaya aman dipakai
# pada teks sampai beberapa MB tanpa risiko ReDoS.
# =============================================================================
SECRET_PLACEHOLDER = "[REDACTED]"
SECRET_PLACEHOLDER_PRIVATE_KEY = "[REDACTED PRIVATE KEY]"


class SecretScan(NamedTuple):
    text: str                 # teks setelah disensor
    hits: int                 # jumlah secret BERBEDA yang disensor (placeholder tidak dihitung)
    kinds: tuple              # jenis temuan (tanpa nilai secret)
    blocked: bool             # True = sebaiknya seluruh file ditolak
    reason: str               # alasan singkat kalau blocked


def _own_secret_values() -> tuple[str, ...]:
    """Nilai rahasia milik bot sendiri (token Discord, API key Xingchi, token Cloudflare)."""
    values: set[str] = set()
    for raw in (DISCORD_TOKEN, XINGCHI_API_KEY):
        if raw and len(raw.strip()) >= 8:
            values.add(raw.strip())
    for acc in CF_ACCOUNTS:
        token = (acc.get("token") or "").strip()
        if len(token) >= 8:
            values.add(token)
    # Terpanjang dulu supaya substring tidak merusak penggantian.
    return tuple(sorted(values, key=len, reverse=True))


_PEM_PRIVATE_KEY_RE = re.compile(
    r"-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----"
    r".*?"
    r"(?:-----END (?:[A-Z0-9]+ )*PRIVATE KEY(?: BLOCK)?-----|\Z)",
    re.DOTALL,
)
_PUTTY_PRIVATE_KEY_RE = re.compile(r"PuTTY-User-Key-File-\d+:.*?(?:Private-MAC:[^\n]*|\Z)", re.DOTALL)
_SERVICE_ACCOUNT_RE = re.compile(r'"type"\s*:\s*"service_account"')

_TOKEN_PATTERNS: tuple[tuple[str, "re.Pattern[str]"], ...] = (
    ("discord-token", re.compile(
        r"(?<![A-Za-z0-9_-])[MNO][A-Za-z0-9_-]{23,27}\.[A-Za-z0-9_-]{6,7}\.[A-Za-z0-9_-]{27,40}(?![A-Za-z0-9_-])")),
    ("discord-mfa-token", re.compile(r"(?<![A-Za-z0-9_-])mfa\.[A-Za-z0-9_-]{80,95}(?![A-Za-z0-9_-])")),
    ("discord-webhook", re.compile(
        r"https?://(?:[a-z]+\.)?discord(?:app)?\.com/api/(?:v\d+/)?webhooks/\d+/[A-Za-z0-9_-]{20,}", re.IGNORECASE)),
    ("slack-webhook", re.compile(r"https://hooks\.slack\.com/services/[A-Za-z0-9/_-]{20,}")),
    ("api-key-sk", re.compile(r"(?<![A-Za-z0-9_-])sk-[A-Za-z0-9_-]{20,}")),
    ("github-token", re.compile(
        r"(?<![A-Za-z0-9_])(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})")),
    ("aws-access-key-id", re.compile(
        r"(?<![A-Za-z0-9])(?:AKIA|ASIA|AGPA|AIDA|AROA|ANPA|ANVA|AIPA)[A-Z0-9]{16}(?![A-Za-z0-9])")),
    ("google-api-key", re.compile(r"(?<![A-Za-z0-9_-])AIza[0-9A-Za-z_-]{35}(?![A-Za-z0-9_-])")),
    ("google-oauth-token", re.compile(r"(?<![A-Za-z0-9_-])ya29\.[0-9A-Za-z_-]{20,}")),
    ("slack-token", re.compile(r"(?<![A-Za-z0-9])xox[abprs]-[A-Za-z0-9-]{10,}")),
    ("stripe-key", re.compile(r"(?<![A-Za-z0-9_])[sr]k_(?:live|test)_[0-9A-Za-z]{16,}")),
    ("huggingface-token", re.compile(r"(?<![A-Za-z0-9_])hf_[A-Za-z0-9]{30,}")),
    ("groq-key", re.compile(r"(?<![A-Za-z0-9_])gsk_[A-Za-z0-9]{40,}")),
    ("npm-token", re.compile(r"(?<![A-Za-z0-9_])npm_[A-Za-z0-9]{36}(?![A-Za-z0-9])")),
    ("sendgrid-key", re.compile(r"(?<![A-Za-z0-9_.-])SG\.[A-Za-z0-9_-]{20,24}\.[A-Za-z0-9_-]{40,50}")),
    ("telegram-bot-token", re.compile(r"(?<![0-9])[0-9]{8,10}:AA[A-Za-z0-9_-]{33}(?![A-Za-z0-9_-])")),
    ("jwt", re.compile(r"(?<![A-Za-z0-9_-])eyJ[A-Za-z0-9_-]{8,}\.eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}")),
)

_URL_CRED_RE = re.compile(
    r"(?P<head>\b[a-zA-Z][a-zA-Z0-9+.-]{1,20}://[^\s/:@\"'<>]{1,128}:)(?P<pw>[^\s/\"'<>]{1,256})@"
)
_BEARER_RE = re.compile(r"(?i)(?P<head>\b(?:bearer|basic)[ \t]+)(?P<tok>[A-Za-z0-9._~+/=-]{16,})")
_CLI_FLAG_RE = re.compile(
    r"(?i)(?P<head>(?<![\w-])--?(?:password|passwd|pass|token|secret|api-?key|access-?key|secret-?key|"
    r"auth-?token|client-?secret|private-?key)(?:=|[ \t]+))"
    r"(?P<val>\"[^\"\n]{4,512}\"|'[^'\n]{4,512}'|[^\s\"']{4,512})"
)
_NETRC_RE = re.compile(
    r"(?im)^(?P<head>[ \t]*(?:machine[ \t]+\S+[ \t]+)?login[ \t]+\S+[ \t]+password[ \t]+)(?P<pw>\S+)"
)
_KV_RE = re.compile(
    r"""(?<![A-Za-z0-9_.\-])(?P<key>[A-Za-z_][A-Za-z0-9_.\-]{0,63})(?P<q>["']?)"""
    r"""(?P<sep>[ \t]*[:=](?!=)[ \t]*)"""
    r"""(?P<val>[rRbBuUfF]{0,2}"[^"\n]{1,2048}"|[rRbBuUfF]{0,2}'[^'\n]{1,2048}'|[^\s"',;#<>&]{1,2048})"""
)
_VALUE_QUOTE_RE = re.compile(r"""^([rRbBuUfF]{0,2})(["'])""")
# Penyaring cepat: pass KV yang lebih mahal hanya jalan kalau ada kata kunci.
_KV_HINT_RE = re.compile(
    r"(?i)secret|token|passw|pwd|passphrase|credential|cookie|bearer|authorization|jwt|sandi|rahasia|[_.\-]key|key[_.\-]|apikey|accesskey"
)

_WORD_SPLIT_RE = re.compile(r"[A-Z]+(?![a-z])|[A-Z]?[a-z]+|[0-9]+")
_SENSITIVE_KEY_WORDS = frozenset({
    "secret", "secrets", "token", "tokens", "password", "passwords", "passwd", "passphrase", "pwd",
    "credential", "credentials", "cookie", "cookies", "bearer", "jwt", "authorization",
    "apikey", "apikeys", "accesskey", "secretkey", "privatekey", "authtoken", "clientsecret",
    "signingkey", "sessionkey", "sandi", "rahasia",
})
_KEY_QUALIFIERS = frozenset({
    "api", "access", "private", "secret", "signing", "encryption", "auth", "master", "license",
    "session", "bot", "service", "webhook", "admin", "root", "hmac", "jwt", "client", "app", "db",
    "database", "ssh", "gpg", "pgp", "aws", "stripe", "openai", "xingchi", "cloudflare", "cf", "discord",
})

_VALUE_REFERENCE_RE = re.compile(
    r"^(?:\$\{[^}]*\}?|\$\([^)]*\)?|\$[A-Z_][A-Z0-9_]*|\{\{.*|%[A-Za-z_][A-Za-z0-9_]*%?"
    r"|(?:os\.)?(?:getenv|environ)\b.*|process\.env\b.*|import\.meta\.env\b.*|System\.getenv\b.*"
    r"|ENV\b[\[.].*|env\(.*|(?:config|settings|secrets|conf|cfg)\.[A-Za-z_].*)$"
)
_VALUE_PLACEHOLDER_RE = re.compile(
    r"^(?:\[[^\]]*\]|<[^>]*>|\*{3,}|x{4,}|\.{3,}|your[\w\-. ]*|my[_-]?(?:secret|token|key|password|api[_-]?key)[\w\-.]*"
    r"|change[-_ ]?me|replace[\w\-.]*|example[\w\-.]*|placeholder[\w\-.]*|insert[\w\-.]*|todo|tbd)$",
    re.IGNORECASE,
)
_VALUE_LITERALS = frozenset({"true", "false", "none", "null", "nil", "undefined", "yes", "no", "on", "off"})
_CALL_EXPR_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*[(\[]")
_TEMPLATE_INTERP_RE = re.compile(r"\{[^{}\n]{1,80}\}|%\([A-Za-z_]\w*\)[sd]")
_CODE_ATTR_CHAIN_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+$")
_CODE_PLAIN_VAR_RE = re.compile(r"^[a-z_][a-z_]{0,40}$")
_ENV_ASSIGN_LINE_RE = re.compile(r"^\s*(?:export\s+)?[A-Za-z_][A-Za-z0-9_.\-]*\s*=\s*\S")
_INI_SECTION_RE = re.compile(r"^\s*\[[^\]\n]{1,100}\]\s*$")

# Ekstensi yang diperlakukan sebagai kode: nilai tanpa kutip dianggap ekspresi.
CODE_EXTS = frozenset({".py", ".js", ".ts"})


def _is_sensitive_key(key: str) -> bool:
    words = [w.lower() for w in _WORD_SPLIT_RE.findall(key)]
    if not words:
        return False
    if any(w in _SENSITIVE_KEY_WORDS for w in words):
        return True
    if "key" in words and any(w in _KEY_QUALIFIERS for w in words if w != "key"):
        return True
    if words[-1] == "pass" or words == ["pass"]:
        return True
    return False


def _looks_like_code_expr(value: str) -> bool:
    if any(ch in value for ch in "()[]{}"):
        return True
    if _CODE_ATTR_CHAIN_RE.match(value):
        return True
    if _CODE_PLAIN_VAR_RE.match(value):
        return True
    return False


def _should_skip_secret_value(inner: str, *, quoted: bool, code_mode: bool) -> tuple[bool, bool]:
    """Return (skip, is_placeholder). Placeholder/referensi/ekspresi kode tidak disensor dan tidak dihitung."""
    stripped = inner.strip()
    # Pembungkus markdown/kalimat (`4096`, "nilai", (x), dst.) tidak ikut menentukan jenis nilai.
    core = stripped.strip("`*_.,;:!?)]}>'\"")
    if not core:
        return True, True
    if core.lower() in _VALUE_LITERALS:
        return True, True
    if core.isdigit() and len(core) <= 5:
        return True, True
    if _VALUE_REFERENCE_RE.match(stripped) or _VALUE_REFERENCE_RE.match(core):
        return True, True
    if _VALUE_PLACEHOLDER_RE.match(stripped) or _VALUE_PLACEHOLDER_RE.match(core):
        return True, True
    if _TEMPLATE_INTERP_RE.search(stripped):  # template / f-string: bukan nilai literal
        return True, True
    if not quoted and (_CALL_EXPR_RE.match(core) or core[:1] in "([{"):
        return True, True  # pemanggilan fungsi/subscript/struktur data: os.getenv(, re.compile(, tuple[
    if code_mode and not quoted and _looks_like_code_expr(core):
        return True, True
    return False, False


def looks_like_env_file(text: str) -> bool:
    """True jika isi tampak seperti file .env datar (KEY=VALUE tanpa struktur).

    File INI ber-[section] sengaja TIDAK dianggap env: cukup disensor nilainya supaya tetap bisa dianalisis.
    """
    considered = 0
    assignments = 0
    for line in text.splitlines()[:3000]:
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", ";", "//")):
            continue
        if _INI_SECTION_RE.match(line):
            return False
        if stripped.startswith("["):  # mis. baris array JSON
            continue
        considered += 1
        if _ENV_ASSIGN_LINE_RE.match(line):
            assignments += 1
    return assignments >= 2 and considered > 0 and (assignments / considered) >= 0.7


def scan_secrets(text: str, *, code_mode: bool = False, allow_env_block: bool = True) -> SecretScan:
    """Sensor secret di `text` dan putuskan apakah seluruh isinya sebaiknya ditolak.

    - Private key (PEM/PuTTY) -> disensor dan blocked.
    - Service-account JSON -> blocked.
    - Isi tampak seperti file .env yang berisi secret -> blocked.
    - >= SECRET_BLOCK_THRESHOLD secret berbeda -> blocked.
    - Selain itu: disensor di tempat dan tetap boleh diproses.
    """
    if not text:
        return SecretScan("", 0, (), False, "")

    out = text
    kinds: list[str] = []
    distinct: set[str] = set()
    has_private_key = False

    def note(kind: str, raw: str) -> None:
        kinds.append(kind)
        distinct.add(f"{kind}:{raw}")

    # 0) Secret milik bot sendiri (exact-match) - kanari paling kuat.
    for own in _own_secret_values():
        if own in out:
            out = out.replace(own, SECRET_PLACEHOLDER)
            note("bot-secret", own)

    # 1) Private key.
    def _private_key(match: "re.Match[str]") -> str:
        nonlocal has_private_key
        has_private_key = True
        note("private-key", match.group(0)[:80])
        return SECRET_PLACEHOLDER_PRIVATE_KEY

    if "PRIVATE KEY" in out:
        out = _PEM_PRIVATE_KEY_RE.sub(_private_key, out)
    if "PuTTY-User-Key-File" in out:
        out = _PUTTY_PRIVATE_KEY_RE.sub(_private_key, out)

    # 2) Format token yang dikenal.
    for kind, pattern in _TOKEN_PATTERNS:
        def _token(match: "re.Match[str]", _kind: str = kind) -> str:
            note(_kind, match.group(0))
            return SECRET_PLACEHOLDER
        out = pattern.sub(_token, out)

    # 3) Kredensial di dalam URL: scheme://user:password@host
    if "@" in out and "://" in out:
        def _url_cred(match: "re.Match[str]") -> str:
            note("url-credential", match.group("pw"))
            return f"{match.group('head')}{SECRET_PLACEHOLDER}@"
        out = _URL_CRED_RE.sub(_url_cred, out)

    # 4) Header Authorization: Bearer/Basic <token>
    def _bearer(match: "re.Match[str]") -> str:
        tok = match.group("tok")
        if tok.isalpha():  # kata biasa, bukan token
            return match.group(0)
        note("bearer-token", tok)
        return f"{match.group('head')}{SECRET_PLACEHOLDER}"
    out = _BEARER_RE.sub(_bearer, out)

    # 5) Flag CLI: --password xxx / --token=xxx
    def _cli(match: "re.Match[str]") -> str:
        val = match.group("val")
        quoted = val[:1] in "\"'"
        inner = val[1:-1] if quoted else val
        skip, _ = _should_skip_secret_value(inner, quoted=quoted, code_mode=code_mode)
        if skip:
            return match.group(0)
        note("cli-secret", inner)
        quote = val[0] if quoted else ""
        return f"{match.group('head')}{quote}{SECRET_PLACEHOLDER}{quote}"
    out = _CLI_FLAG_RE.sub(_cli, out)

    # 6) Format .netrc
    def _netrc(match: "re.Match[str]") -> str:
        note("netrc-password", match.group("pw"))
        return f"{match.group('head')}{SECRET_PLACEHOLDER}"
    out = _NETRC_RE.sub(_netrc, out)

    # 7) Pasangan key=value / "key": "value" dengan nama key sensitif.
    if _KV_HINT_RE.search(out):
        def _kv(match: "re.Match[str]") -> str:
            key = match.group("key")
            if not _is_sensitive_key(key):
                return match.group(0)
            val = match.group("val")
            quote_match = _VALUE_QUOTE_RE.match(val)
            quoted = quote_match is not None
            prefix = quote_match.group(1) if quote_match else ""
            quote = quote_match.group(2) if quote_match else ""
            inner = val[len(prefix) + 1:-1] if quoted else val
            skip, _ = _should_skip_secret_value(inner, quoted=quoted, code_mode=code_mode)
            if skip:
                return match.group(0)
            note("key-value", inner)
            head = match.string[match.start():match.start("val")]
            return f"{head}{prefix}{quote}{SECRET_PLACEHOLDER}{quote}"
        out = _KV_RE.sub(_kv, out)

    hits = len(distinct)
    unique_kinds = tuple(dict.fromkeys(kinds))

    blocked = False
    reason = ""
    if has_private_key:
        blocked, reason = True, "berisi private key"
    elif _SERVICE_ACCOUNT_RE.search(text) and ("private_key" in text or "client_email" in text):
        blocked, reason = True, "berisi kredensial service-account"
    elif allow_env_block and hits >= 1 and looks_like_env_file(text):
        blocked, reason = True, "tampak seperti file konfigurasi/.env berisi secret"
    elif hits >= SECRET_BLOCK_THRESHOLD:
        blocked, reason = True, f"berisi banyak secret ({hits} nilai)"

    return SecretScan(out, hits, unique_kinds, blocked, reason)


def scrub_secrets(text: str, *, code_mode: bool = True) -> str:
    """Versi ringkas: hanya mengembalikan teks yang sudah disensor (dipakai untuk chat/log/error)."""
    if not text:
        return text or ""
    return scan_secrets(text, code_mode=code_mode, allow_env_block=False).text


def scrub_own_secrets(text: str) -> str:
    """Sensor cepat khusus nilai rahasia bot sendiri (untuk output model)."""
    if not text:
        return text or ""
    for own in _own_secret_values():
        if own in text:
            text = text.replace(own, SECRET_PLACEHOLDER)
    return text


def safe_exc_text(exc: BaseException, limit: int = 300) -> str:
    """Teks exception yang aman ditampilkan ke Discord / dikirim ke model."""
    return scrub_secrets(f"{type(exc).__name__}: {exc}")[:limit]


# ---------------------------------------------------------------------------
# Kebijakan nama file sensitif (dicek SEBELUM file dibaca sama sekali).
# ---------------------------------------------------------------------------
_SENSITIVE_EXACT_NAMES = frozenset({
    ".env", "env", ".envrc", ".netrc", "_netrc", ".npmrc", ".pypirc", ".htpasswd", ".git-credentials",
    ".pgpass", ".my.cnf", ".dockercfg", "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519",
    "credentials", "credentials.json", "secrets.json", "secrets.yml", "secrets.yaml", "secret.json",
    "service-account.json", "serviceaccount.json", "service_account.json", "client_secret.json",
    "master.key", "wallet.dat", "shadow", "kubeconfig", "terraform.tfstate", "terraform.tfvars",
})
_SENSITIVE_EXTENSIONS = frozenset({
    ".env", ".pem", ".key", ".p12", ".pfx", ".p8", ".jks", ".keystore", ".ppk", ".gpg",
    ".kdbx", ".kdb", ".tfvars", ".tfstate", ".ovpn",
})
_ENV_FILENAME_RE = re.compile(
    r"^(?:\.env(?:[._-].*)?"
    r"|env\.(?:txt|local|prod|production|dev|development|staging|test|bak|backup|example|sample|json|ya?ml|ini|cfg|conf)"
    r"|.*\.env(?:\.[a-z0-9_-]+)?)$"
)
_SENSITIVE_NAME_WORDS_RE = re.compile(
    r"(?<![a-z0-9])(?:secrets?|credentials?|passwords?|passwd|private[-_ ]?keys?|api[-_ ]?keys?|apikeys?"
    r"|client[-_ ]?secrets?|service[-_ ]?accounts?|access[-_ ]?keys?|secret[-_ ]?keys?"
    r"|(?:auth|access|refresh|bot|api)[-_ ]?tokens?|kata[-_ ]?sandi|sandi|rahasia)(?![a-z0-9])"
)


def classify_sensitive_filename(filename: str) -> str | None:
    """Kembalikan alasan penolakan jika NAMA file menunjukkan kredensial/rahasia, selain itu None."""
    name = os.path.basename((filename or "").replace("\\", "/")).strip().lower()
    if not name:
        return None
    if name in _SENSITIVE_EXACT_NAMES or _ENV_FILENAME_RE.match(name):
        return "file environment/kredensial"
    ext = os.path.splitext(name)[1]
    if ext in _SENSITIVE_EXTENSIONS:
        return f"file kunci/sertifikat privat ({ext})"
    if _SENSITIVE_NAME_WORDS_RE.search(name):
        return "nama file menunjukkan kredensial/rahasia"
    return None


# ---------------------------------------------------------------------------
# Rate limiter per pengguna (in-memory, dipakai dari satu event loop -> tanpa lock).
# ---------------------------------------------------------------------------
class RateRule(NamedTuple):
    min_interval: float   # jeda minimum antar request (detik); 0 = nonaktif
    max_events: int       # maksimum request per jendela; 0 = nonaktif
    window: float         # panjang jendela (detik)


# kategori: (jeda minimum, maks per jendela, panjang jendela)
_RATE_DEFAULTS: dict[str, tuple[float, int, float]] = {
    "chat": (4.0, 10, 60.0),
    "file": (12.0, 6, 300.0),
    "image": (20.0, 8, 600.0),
    "regen": (8.0, 6, 120.0),
    "summarize": (60.0, 3, 600.0),
    "diagnostic": (120.0, 3, 3600.0),
    "dm": (5.0, 5, 120.0),
}


def load_rate_rules() -> dict[str, RateRule]:
    rules: dict[str, RateRule] = {}
    for category, (cooldown, max_events, window) in _RATE_DEFAULTS.items():
        up = category.upper()
        rules[category] = RateRule(
            min_interval=_env_float(f"RATE_{up}_COOLDOWN", cooldown),
            max_events=_env_int(f"RATE_{up}_MAX", max_events),
            window=_env_float(f"RATE_{up}_WINDOW", window, minimum=1.0),
        )
    return rules


def format_wait(seconds: float) -> str:
    secs = max(1, int(math.ceil(seconds)))
    if secs < 90:
        return f"{secs} detik"
    if secs < 5400:
        return f"{int(math.ceil(secs / 60))} menit"
    return f"{int(math.ceil(secs / 3600))} jam"


class RateLimiter:
    """Pembatas laju: jeda minimum + jendela geser per (kategori, pengguna) + kuota harian opsional."""

    DAILY_WINDOW = 86400.0
    _PRUNE_THRESHOLD = 5000

    def __init__(
        self,
        rules: dict[str, RateRule],
        *,
        daily_limit: int = 0,
        exempt_ids=(),
        enabled: bool = True,
        clock=time.monotonic,
    ):
        self.rules = dict(rules)
        self.daily_limit = max(0, int(daily_limit))
        self.exempt_ids = frozenset(int(x) for x in exempt_ids)
        self.enabled = bool(enabled)
        self._clock = clock
        self._events: dict[tuple[str, int], deque] = {}
        self._daily: dict[int, list] = {}  # uid -> [awal_jendela, jumlah]  (O(1) memori per pengguna)
        self._notified: dict[int, float] = {}

    def acquire(self, category: str, user_id: int, *, counts_daily: bool = True) -> tuple[bool, float]:
        """Coba pakai satu jatah. Return (diizinkan, detik_tunggu). Hanya mencatat kalau diizinkan."""
        uid = int(user_id)
        if not self.enabled or uid in self.exempt_ids:
            return True, 0.0
        rule = self.rules.get(category)
        if rule is None:
            return True, 0.0

        now = self._clock()
        key = (category, uid)
        events = self._events.get(key)
        if events is None:
            events = deque(maxlen=rule.max_events if rule.max_events > 0 else 1)
            self._events[key] = events

        wait = 0.0
        if events and rule.min_interval > 0:
            gap = now - events[-1]
            if gap < rule.min_interval:
                wait = max(wait, rule.min_interval - gap)
        if rule.max_events > 0 and len(events) >= rule.max_events:
            age = now - events[0]
            if age < rule.window:
                wait = max(wait, rule.window - age)

        daily = None
        if counts_daily and self.daily_limit > 0:
            daily = self._daily.get(uid)
            if daily is None or (now - daily[0]) >= self.DAILY_WINDOW:
                daily = [now, 0]  # jendela harian baru dimulai pada request pertama
                self._daily[uid] = daily
            if daily[1] >= self.daily_limit:
                wait = max(wait, self.DAILY_WINDOW - (now - daily[0]))

        if wait > 0:
            if len(self._events) > self._PRUNE_THRESHOLD:
                self._prune(now)
            return False, wait

        events.append(now)
        if daily is not None:
            daily[1] += 1
        if len(self._events) > self._PRUNE_THRESHOLD:
            self._prune(now)
        return True, 0.0

    def should_notify(self, user_id: int, interval: float = 30.0) -> bool:
        """True jika pengguna ini belum diberi tahu 'kena rate limit' dalam `interval` detik terakhir."""
        uid = int(user_id)
        now = self._clock()
        last = self._notified.get(uid)
        if last is not None and (now - last) < interval:
            return False
        self._notified[uid] = now
        return True

    def _prune(self, now: float) -> None:
        longest = max([r.window for r in self.rules.values()] + [1.0])
        for key in [k for k, dq in self._events.items() if not dq or (now - dq[-1]) > longest]:
            self._events.pop(key, None)
        for uid in [u for u, (start, _count) in self._daily.items() if (now - start) >= self.DAILY_WINDOW]:
            self._daily.pop(uid, None)
        for uid in [u for u, ts in self._notified.items() if (now - ts) > 300.0]:
            self._notified.pop(uid, None)


def rate_limit_text(wait: float) -> str:
    return f"⏳ Pelan-pelan dulu ya. Coba lagi sekitar **{format_wait(wait)}**."


# ---------------------------------------------------------------------------
# Penyimpanan state tombol AI (Regenerate / DM) - dibatasi & persisten.
# ---------------------------------------------------------------------------
def _content_to_text(content) -> tuple[str, int]:
    """Ratakan content pesan (str atau list blok) jadi teks. Return (teks, jumlah_gambar)."""
    if isinstance(content, str):
        return content, 0
    if not isinstance(content, list):
        return str(content or ""), 0
    parts: list[str] = []
    images = 0
    for block in content:
        if not isinstance(block, dict):
            continue
        btype = block.get("type")
        if btype == "text":
            parts.append(str(block.get("text", "")))
        elif btype == "image_url":
            images += 1
            parts.append("[Gambar]")
    return "\n".join(parts).strip(), images


def _message_has_image(message: dict) -> bool:
    content = message.get("content")
    return isinstance(content, list) and any(
        isinstance(b, dict) and b.get("type") == "image_url" for b in content
    )


def strip_images_from_messages(messages: list[dict]) -> list[dict]:
    stripped: list[dict] = []
    for msg in messages:
        if _message_has_image(msg):
            text, _ = _content_to_text(msg.get("content"))
            stripped.append({"role": msg.get("role", "user"), "content": text or "[Gambar]"})
        else:
            stripped.append(msg)
    return stripped


def compact_messages_for_disk(messages: list[dict], max_chars: int) -> list[dict]:
    """Versi teks-saja yang dipangkas: pesan terbaru selalu ikut, yang lama dibuang bila melebihi anggaran."""
    flat: list[dict] = []
    for msg in messages:
        if not isinstance(msg, dict) or msg.get("role") not in ("user", "assistant"):
            continue
        text, _ = _content_to_text(msg.get("content"))
        flat.append({"role": msg["role"], "content": text})
    kept: list[dict] = []
    budget = max(1000, int(max_chars))
    for msg in reversed(flat):
        size = len(msg["content"])
        if not kept:
            if size > budget:
                msg = {"role": msg["role"], "content": msg["content"][:budget] + "\n...(dipotong)"}
                size = budget
            kept.append(msg)
            budget -= size
            continue
        if size <= budget:
            kept.append(msg)
            budget -= size
        else:
            break
    kept.reverse()
    return kept


class ViewStateStore:
    """Menyimpan snapshot yang dibutuhkan tombol Regenerate/DM, per ID pesan Discord.

    Tiga lapis batas supaya RAM & disk tidak membengkak:
      * `max_entries`   : jumlah pesan yang diingat (hanya info ringan: pemilik, mode).
      * `max_snapshots` : jumlah pesan yang masih menyimpan riwayat teks untuk Regenerate.
      * `live_media`    : jumlah pesan terbaru yang masih menyimpan payload PENUH + gambar (hanya di RAM, tidak
                          pernah ke disk). Di luar jendela ini snapshot dipadatkan jadi teks-saja <= snapshot_chars.
    """

    def __init__(
        self,
        path: str,
        *,
        max_entries: int = 2000,
        max_snapshots: int = 100,
        live_media: int = 20,
        snapshot_chars: int = 48_000,
        retention_seconds: float = 14 * 86400,
        clock=time.time,
    ):
        self.path = path
        self.max_entries = max(1, int(max_entries))
        self.max_snapshots = max(1, int(max_snapshots))
        self.live_media = max(0, int(live_media))
        self.snapshot_chars = max(1000, int(snapshot_chars))
        self.retention_seconds = float(retention_seconds)
        self._clock = clock
        self._entries: "OrderedDict[int, dict]" = OrderedDict()
        self._dirty = False
        self._save_lock = asyncio.Lock()
        self._load()

    def __len__(self) -> int:
        return len(self._entries)

    # -- API publik ---------------------------------------------------------
    def put(
        self,
        message_id: int,
        *,
        owner_id: int,
        messages: list[dict],
        mode: str,
        allow_image_tool: bool,
        user_prompt_text: str,
        source_images: list[str] | None,
    ) -> None:
        snapshot = [
            copy.deepcopy(m) for m in messages
            if isinstance(m, dict) and m.get("role") in ("user", "assistant")
        ]
        images = list(source_images or [])[:MAX_VISION_IMAGES_PER_TURN]
        had_images = bool(images) or any(_message_has_image(m) for m in snapshot)
        mid = int(message_id)
        self._entries[mid] = {
            "owner_id": int(owner_id),
            "mode": "full" if mode == "full" else "fast",
            "allow_image_tool": bool(allow_image_tool),
            "user_prompt_text": str(user_prompt_text or "")[:4000],
            "messages": snapshot,
            "source_images": images,
            "had_images": had_images,
            "media_dropped": False,
            "ts": self._clock(),
        }
        self._entries.move_to_end(mid)
        self._dirty = True
        self._enforce_limits()

    def get(self, message_id: int) -> dict | None:
        mid = int(message_id)
        entry = self._entries.get(mid)
        if entry is None:
            return None
        if (self._clock() - entry["ts"]) > self.retention_seconds:
            self._entries.pop(mid, None)
            self._dirty = True
            return None
        self._entries.move_to_end(mid)
        return entry

    async def save(self) -> None:
        if not self._dirty:
            return
        async with self._save_lock:
            if not self._dirty:
                return
            payload = self._disk_payload()
            self._dirty = False
            try:
                await asyncio.to_thread(self._write_atomic, payload)
            except Exception:
                self._dirty = True
                logging.exception("Gagal menyimpan %s", self.path)

    # -- internal -----------------------------------------------------------
    def _enforce_limits(self) -> None:
        now = self._clock()
        expired = [m for m, e in self._entries.items() if (now - e["ts"]) > self.retention_seconds]
        for mid in expired:
            self._entries.pop(mid, None)
        while len(self._entries) > self.max_entries:
            self._entries.popitem(last=False)

        total = len(self._entries)
        for index, mid in enumerate(list(self._entries.keys())):
            entry = self._entries[mid]
            rank = total - 1 - index  # 0 = paling baru
            if rank >= self.max_snapshots:
                if entry.get("messages") is not None or entry.get("source_images"):
                    entry["messages"] = None
                    entry["source_images"] = []
                    if entry.get("had_images"):
                        entry["media_dropped"] = True
                continue
            if rank >= self.live_media and not entry.get("compacted"):
                # Di luar jendela "live": teks-saja + dipangkas (<= snapshot_chars). Gambar & teks besar dilepas dari RAM.
                entry["messages"] = compact_messages_for_disk(entry.get("messages") or [], self.snapshot_chars)
                entry["source_images"] = []
                entry["compacted"] = True
                if entry.get("had_images"):
                    entry["media_dropped"] = True

    def _disk_payload(self) -> dict:
        entries: dict[str, dict] = {}
        for mid, entry in self._entries.items():
            messages = entry.get("messages")
            entries[str(mid)] = {
                "owner_id": entry["owner_id"],
                "mode": entry["mode"],
                "allow_image_tool": entry["allow_image_tool"],
                "user_prompt_text": entry["user_prompt_text"],
                "messages": (
                    compact_messages_for_disk(messages, self.snapshot_chars) if messages is not None else None
                ),
                "had_images": bool(entry.get("had_images")),
                "ts": entry["ts"],
            }
        return {"version": 1, "entries": entries}

    def _write_atomic(self, payload: dict) -> None:
        tmp_path = f"{self.path}.tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as fh:
                json.dump(payload, fh, ensure_ascii=False)
            try:
                os.chmod(tmp_path, 0o600)
            except OSError:
                pass
            os.replace(tmp_path, self.path)
        except Exception:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except OSError:
                pass
            raise

    def _load(self) -> None:
        if not os.path.exists(self.path):
            return
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            raw_entries = data.get("entries") if isinstance(data, dict) else None
            if not isinstance(raw_entries, dict):
                return
            loaded: list[tuple[float, int, dict]] = []
            for raw_id, raw in raw_entries.items():
                if not isinstance(raw, dict) or not str(raw_id).isdigit():
                    continue
                owner = raw.get("owner_id")
                ts = raw.get("ts")
                if not isinstance(owner, int) or isinstance(owner, bool):
                    continue
                if not isinstance(ts, (int, float)) or isinstance(ts, bool):
                    continue
                messages = raw.get("messages")
                clean_messages = None
                if isinstance(messages, list):
                    clean_messages = [
                        {"role": m["role"], "content": m["content"]}
                        for m in messages
                        if isinstance(m, dict) and m.get("role") in ("user", "assistant")
                        and isinstance(m.get("content"), str)
                    ]
                had_images = bool(raw.get("had_images"))
                loaded.append((float(ts), int(raw_id), {
                    "owner_id": owner,
                    "mode": "full" if raw.get("mode") == "full" else "fast",
                    "allow_image_tool": bool(raw.get("allow_image_tool", True)),
                    "user_prompt_text": str(raw.get("user_prompt_text") or "")[:4000],
                    "messages": clean_messages,
                    "source_images": [],
                    "had_images": had_images,
                    "media_dropped": had_images,
                    "compacted": True,
                    "ts": float(ts),
                }))
            for _, mid, entry in sorted(loaded, key=lambda item: item[0]):
                self._entries[mid] = entry
            self._enforce_limits()
        except Exception:
            logging.exception("Gagal memuat %s; memulai dengan state tombol kosong", self.path)
            self._entries.clear()


# ---------------------------------------------------------------------------
# Redaksi log: token/API key tidak boleh muncul di konsol hosting atau tiket dukungan.
# ---------------------------------------------------------------------------
class SecretRedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            message = record.getMessage()
            cleaned = scrub_secrets(message)
            if cleaned != message:
                record.msg = cleaned
                record.args = ()
            if record.exc_info and not record.exc_text:
                record.exc_text = logging.Formatter().formatException(record.exc_info)
            if record.exc_text:
                record.exc_text = scrub_secrets(record.exc_text)
            if record.stack_info:
                record.stack_info = scrub_secrets(record.stack_info)
        except Exception:
            pass
        return True


def install_log_redaction() -> None:
    redaction = SecretRedactionFilter()
    root = logging.getLogger()
    for handler in root.handlers:
        if not any(isinstance(f, SecretRedactionFilter) for f in handler.filters):
            handler.addFilter(redaction)


def check_runtime_config() -> list[str]:
    """Validasi konfigurasi yang menyangkut kredensial. Raise RuntimeError untuk kondisi fatal."""
    warnings: list[str] = []
    if not XINGCHI_BASE_URL.lower().startswith("https://") and not _env_bool("ALLOW_INSECURE_BASE_URL", False):
        raise RuntimeError(
            "XINGCHI_BASE_URL harus memakai https:// supaya API key tidak terkirim polos. "
            "(Khusus pengembangan lokal: set ALLOW_INSECURE_BASE_URL=1.)"
        )
    for label, value in (("DISCORD_TOKEN", DISCORD_TOKEN), ("XINGCHI_API_KEY", XINGCHI_API_KEY)):
        if value and re.fullmatch(r"(?i)(?:your|isi|ganti|changeme|xxx+|<.*>)[\w\-. ]*", value.strip()):
            warnings.append(f"{label} masih tampak seperti placeholder.")
    if not CF_ACCOUNTS:
        warnings.append("CF_ACCOUNTS_JSON kosong/tidak valid: generate gambar & transkripsi audio akan terbatas.")
    return warnings


# ---------------------------------------------------------------------------
# Helper keamanan tingkat modul.
# ---------------------------------------------------------------------------
_ZIP_BASED_EXTS = frozenset({".docx", ".pptx", ".xlsx", ".odt", ".ods", ".odp", ".epub"})


def check_file_signature(ext: str, data: bytes) -> str | None:
    """Cocokkan isi file dengan ekstensinya (anti file yang diberi nama menyesatkan). None = lolos."""
    if ext == ".pdf":
        return None if b"%PDF-" in data[:1024] else "isi file bukan PDF yang valid"
    if ext in _ZIP_BASED_EXTS:
        return None if data[:4] in (b"PK\x03\x04", b"PK\x05\x06") else "isi file bukan arsip Office/EPUB yang valid"
    if ext == ".rtf":
        return None if data.lstrip()[:5] == b"{\\rtf" else "isi file bukan RTF yang valid"
    return None


_XML_ENTITY_DECL_RE = re.compile(rb"<!ENTITY\s+(%\s+)?[^\s>]+\s+(SYSTEM|PUBLIC|\"[^\"]*\"|'[^']*')", re.IGNORECASE)
_XML_NESTED_ENTITY_RE = re.compile(rb"<!ENTITY\s+[^\s>]+\s+(?:\"[^\"]*&[A-Za-z_#][^\";]*;[^\"]*\"|'[^']*&[A-Za-z_#][^';]*;[^']*')")


def safe_xml_fromstring(raw: bytes):
    """ET.fromstring dengan penolakan entity-expansion (billion laughs) dan external/parameter entity.

    DOCTYPE biasa dan deklarasi entity sederhana (mis. header SVG dari Illustrator) tetap diterima.
    """
    if b"<!ENTITY" in raw:
        if raw.count(b"<!ENTITY") > 20:
            raise ValueError("XML ditolak: terlalu banyak deklarasi entity")
        for match in _XML_ENTITY_DECL_RE.finditer(raw):
            if match.group(1) or match.group(2).upper() in (b"SYSTEM", b"PUBLIC"):
                raise ValueError("XML ditolak: external/parameter entity tidak diizinkan")
        if _XML_NESTED_ENTITY_RE.search(raw):
            raise ValueError("XML ditolak: entity bersarang (indikasi XML bomb)")
    return ET.fromstring(raw)


def message_char_len(message: dict) -> int:
    text, images = _content_to_text(message.get("content"))
    return len(text) + images * 1000


async def reply_ephemeral(interaction: "discord.Interaction", text: str) -> None:
    """Balas interaksi secara ephemeral, aman dipanggil walau interaksi sudah direspons."""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True)
        else:
            await interaction.response.send_message(text, ephemeral=True)
    except Exception:
        logging.exception("Gagal mengirim balasan ephemeral")


class AIResponseView(discord.ui.View):
    """View PERSISTEN & stateless untuk tombol di bawah jawaban AI.

    * timeout=None + custom_id tetap -> tombol tetap hidup setelah 10 menit DAN setelah bot restart
      (satu instance ini didaftarkan sekali lewat bot.add_view() di setup_hook dan menangani semua pesan).
    * State per-pesan (pemilik, mode, riwayat untuk Regenerate) disimpan di ClouzerBot.view_states
      (dibatasi + disimpan ke view_state.json), BUKAN di objek view ini. Jadi view yang hidup selamanya
      tidak menahan riwayat/gambar di RAM.
    """

    def __init__(self, bot_instance):
        super().__init__(timeout=None)
        self.bot_instance = bot_instance

    async def _authorize(self, interaction: discord.Interaction) -> dict | None:
        """Ambil state pesan + pastikan yang menekan adalah pemilik percakapan."""
        message = interaction.message
        state = self.bot_instance.view_states.get(message.id) if message is not None else None
        if state is None:
            await reply_ephemeral(
                interaction,
                "⌛ Tombol ini sudah kedaluwarsa (pesannya terlalu lama atau datanya sudah dibersihkan). Kirim pesan baru ya.",
            )
            return None
        if interaction.user.id != state["owner_id"]:
            await reply_ephemeral(
                interaction,
                "⚠️ Tombol ini hanya bisa digunakan oleh pengguna yang memulai percakapan tersebut.",
            )
            return None
        return state

    @discord.ui.button(label="\U0001f504 Regenerate", style=discord.ButtonStyle.secondary, custom_id="ai_regenerate")
    async def regenerate_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        state = await self._authorize(interaction)
        if state is None:
            return
        if state.get("messages") is None:
            await reply_ephemeral(
                interaction,
                "⌛ Riwayat untuk jawaban ini sudah dibersihkan karena terlalu lama. Kirim pertanyaanmu lagi ya.",
            )
            return
        if state.get("had_images") and state.get("media_dropped"):
            await reply_ephemeral(
                interaction,
                "🖼️ Gambar asli untuk jawaban ini sudah tidak tersimpan (bot sempat restart atau sudah lama). "
                "Kirim ulang gambarnya kalau mau jawabannya disusun ulang.",
            )
            return

        message_id = interaction.message.id
        busy = self.bot_instance.view_busy
        if message_id in busy:
            await reply_ephemeral(interaction, "⏳ Jawaban ini sedang disusun ulang, tunggu sebentar ya.")
            return
        allowed, wait = self.bot_instance.rate_limiter.acquire("regen", interaction.user.id)
        if not allowed:
            await reply_ephemeral(interaction, rate_limit_text(wait))
            return

        busy.add(message_id)
        try:
            await self._run_regenerate(interaction, state)
        finally:
            busy.discard(message_id)

    async def _run_regenerate(self, interaction: discord.Interaction, state: dict):
        """Badan Regenerate asli. State diambil dari ViewStateStore (bukan atribut view)."""
        original_messages = [{"role": "system", "content": BASE_SYSTEM_PROMPT}] + list(state["messages"])
        mode = state["mode"]
        source_images = list(state.get("source_images") or [])
        user_prompt_text = state.get("user_prompt_text") or ""
        allow_image_tool = bool(state.get("allow_image_tool", True))
        try:
            await interaction.response.edit_message(content="🔄 *Sedang menyusun ulang jawaban...*", view=self)
        except Exception:
            try:
                await interaction.response.defer()
            except Exception:
                pass

        scope_key = self.bot_instance.get_scope_key(
            interaction.guild, interaction.user.id, interaction.channel_id
        )
        guild_id = interaction.guild.id if interaction.guild is not None else 0
        channel_id = interaction.channel_id or 0
        user_id = interaction.user.id

        try:
            async with self.bot_instance.guild_locks[scope_key]:
                new_reply, function_calls = await self.bot_instance.run_responses_ai(
                    original_messages,
                    interaction.message,
                    mode,
                    allow_tools=True,
                    allow_image_tool=allow_image_tool,
                )

                img_calls = [fc for fc in function_calls if fc.get("name") == "generate_image"]
                unsupported_calls = [fc for fc in function_calls if fc.get("name") != "generate_image"]
                if unsupported_calls:
                    rejected_items = build_failure_tool_continuation(
                        function_calls,
                        "Function tool tidak didukung oleh bot ini. Tool yang tersedia hanya generate_image; web_search ditangani provider.",
                    )
                    if rejected_items:
                        try:
                            follow_text, _ = await self.bot_instance.run_responses_ai(
                                original_messages,
                                interaction.message,
                                mode=mode,
                                allow_tools=False,
                                allow_image_tool=False,
                                extra_input=rejected_items,
                            )
                            if follow_text:
                                new_reply = follow_text
                        except Exception as exc:
                            logging.exception("Continuation unsupported tool gagal saat Regenerate (%s)", scope_key)
                            new_reply = f"⚠️ Tool dari model tidak didukung dan kelanjutan gagal: {type(exc).__name__}."
                    function_calls = []
                    img_calls = []

                image_block_reason = None
                image_rate_wait = 0.0
                if img_calls and not allow_image_tool:
                    image_block_reason = "Pengguna hanya meminta analisis/penjelasan, bukan pembuatan atau pengeditan gambar."
                elif img_calls:
                    img_allowed, image_rate_wait = self.bot_instance.rate_limiter.acquire("image", user_id)
                    if not img_allowed:
                        image_block_reason = (
                            "Batas pemakaian pembuatan/edit gambar untuk pengguna ini sudah tercapai. "
                            f"Jelaskan singkat bahwa gambar bisa dibuat lagi sekitar {format_wait(image_rate_wait)} lagi."
                        )
                if image_block_reason:
                    blocked_items = build_failure_tool_continuation(img_calls, image_block_reason)
                    if blocked_items:
                        try:
                            blocked_text, _ = await self.bot_instance.run_responses_ai(
                                original_messages,
                                interaction.message,
                                mode=mode,
                                allow_tools=False,
                                allow_image_tool=False,
                                extra_input=blocked_items,
                            )
                            if blocked_text:
                                new_reply = blocked_text
                        except Exception:
                            logging.exception("Continuation blocked image call gagal saat Regenerate (%s)", scope_key)
                    if image_rate_wait and not new_reply:
                        new_reply = f"⏳ Batas pembuatan/edit gambar tercapai. Coba lagi sekitar {format_wait(image_rate_wait)}."
                    img_calls = []

                if img_calls and allow_image_tool:
                    if self.bot_instance.is_user_image_busy(user_id) and interaction.message is not None:
                        try:
                            await interaction.message.edit(content="⏳ *Menunggu antrean proses gambar sebelumnya selesai...*", view=self)
                        except Exception:
                            pass

                    async with self.bot_instance.user_image_queue(user_id):
                        unresolved_img_calls = list(img_calls)
                        is_edit = False
                        try:
                            primary_call = img_calls[0]
                            extra_calls = img_calls[1:]

                            try:
                                args_dict = json.loads(primary_call.get("arguments", "{}"))
                            except Exception:
                                args_dict = {}

                            img_prompt = (args_dict.get("prompt") or user_prompt_text or "Create a detailed image").strip()
                            use_attached = bool(args_dict.get("use_attached_image", False))
                            req_ratio = args_dict.get("aspect_ratio") or extract_aspect_ratio_from_text(user_prompt_text)
                            wants_edit = use_attached or any(k in (user_prompt_text or "").lower() for k in EDIT_INTENT_KEYWORDS)

                            source_imgs = (
                                source_images
                                or self.bot_instance.get_last_user_image(guild_id, channel_id, user_id)
                            ) if (use_attached or wants_edit) else None

                            if wants_edit and not source_imgs:
                                fail_items = build_failure_tool_continuation(
                                    unresolved_img_calls, "Gambar sumber untuk edit tidak ditemukan."
                                )
                                unresolved_img_calls = []
                                if fail_items:
                                    try:
                                        follow_text, _ = await self.bot_instance.run_responses_ai(
                                            original_messages,
                                            interaction.message,
                                            mode=mode,
                                            allow_tools=False,
                                            allow_image_tool=False,
                                            extra_input=fail_items,
                                        )
                                        if follow_text:
                                            new_reply = follow_text
                                    except Exception:
                                        logging.exception("Continuation missing source image gagal saat Regenerate (%s)", scope_key)
                                err_content = "⚠️ Regenerate edit gambar gagal: gambar sumber tidak ditemukan."
                                if interaction.message is not None:
                                    await interaction.message.edit(content=err_content, view=self)
                                else:
                                    await interaction.edit_original_response(content=err_content, view=self)
                                return

                            is_edit = bool(source_imgs)
                            if interaction.message is not None:
                                await interaction.message.edit(
                                    content="🖌️ *Sedang mengedit ulang gambar...*" if is_edit else "🎨 *Sedang membuat ulang gambar...*",
                                    view=self,
                                )

                            img_bytes, out_filename, out_mime, engine_used = await self.bot_instance.generate_or_edit_image(
                                img_prompt, source_images=source_imgs, aspect_ratio=req_ratio
                            )

                            continuation_items: list[dict] = []
                            p_call_id = primary_call.get("call_id")
                            if p_call_id:
                                continuation_items.append(primary_call)
                                continuation_items.append({
                                    "type": "function_call_output",
                                    "call_id": p_call_id,
                                    "output": json.dumps({
                                        "success": True,
                                        "operation": "edit_image" if is_edit else "generate_image",
                                        "engine": engine_used,
                                        "filename": out_filename,
                                    }, ensure_ascii=False),
                                })

                            for extra_fc in extra_calls:
                                e_call_id = extra_fc.get("call_id")
                                if e_call_id:
                                    continuation_items.append(extra_fc)
                                    continuation_items.append({
                                        "type": "function_call_output",
                                        "call_id": e_call_id,
                                        "output": json.dumps({
                                            "success": False,
                                            "skipped": True,
                                            "reason": "Hanya satu panggilan gambar utama yang diproses per giliran."
                                        }, ensure_ascii=False),
                                    })

                            unresolved_img_calls = []
                            if continuation_items:
                                try:
                                    follow_text, _ = await self.bot_instance.run_responses_ai(
                                        original_messages,
                                        interaction.message,
                                        mode=mode,
                                        allow_tools=False,
                                        allow_image_tool=False,
                                        extra_input=continuation_items,
                                    )
                                    if follow_text:
                                        new_reply = follow_text
                                except Exception:
                                    logging.exception("Continuation sukses gambar gagal saat Regenerate (%s)", scope_key)

                            if channel_id:
                                context_image = await asyncio.to_thread(
                                    self.bot_instance._compress_image_bytes_to_data_url, img_bytes
                                )
                                self.bot_instance.set_last_user_image(
                                    guild_id, channel_id, user_id, [context_image]
                                )

                            file = discord.File(fp=io.BytesIO(img_bytes), filename=out_filename)
                            embed_title = "🖌️ Clouzer AI Image Editor" if is_edit else "🎨 Clouzer AI Image Generator"
                            embed_desc = f"**Prompt:** {img_prompt[:3600]}"
                            if is_edit:
                                embed_desc = f"{embed_desc[:3450]}\n\n{TEXT_EDIT_NOTE}"

                            embed = discord.Embed(
                                title=embed_title,
                                description=embed_desc,
                                color=discord.Color.blurple(),
                            )
                            embed.set_image(url=f"attachment://{out_filename}")
                            embed.set_footer(text=f"Created by clouzerd | API: {engine_used}")

                            extra_note = f"\n\n{TEXT_EDIT_NOTE}" if is_edit else ""
                            combined = f"**Hasil Regenerate:**\n\n{(new_reply or '').strip()}{extra_note}".strip()
                            final_content = combined[:DISCORD_MSG_CHUNK_LIMIT] if combined else None

                            if interaction.message is not None:
                                await interaction.message.edit(content=final_content, embed=embed, attachments=[file], view=self)
                            else:
                                await interaction.edit_original_response(content=final_content, embed=embed, attachments=[file], view=self)
                            return
                        except Exception as img_exc:
                            if unresolved_img_calls:
                                fail_items = build_failure_tool_continuation(
                                    unresolved_img_calls, f"Proses gambar gagal: {safe_exc_text(img_exc)}"
                                )
                                unresolved_img_calls = []
                                if fail_items:
                                    try:
                                        follow_text, _ = await self.bot_instance.run_responses_ai(
                                            original_messages,
                                            interaction.message,
                                            mode=mode,
                                            allow_tools=False,
                                            allow_image_tool=False,
                                            extra_input=fail_items,
                                        )
                                        if follow_text:
                                            new_reply = follow_text
                                    except Exception:
                                        logging.exception("Continuation exception gambar gagal saat Regenerate (%s)", scope_key)
                            if is_edit:
                                err_content = f"⚠️ Regenerate edit gambar gagal ({safe_exc_text(img_exc)})."[:1990]
                                if interaction.message is not None:
                                    await interaction.message.edit(content=err_content, view=self)
                                else:
                                    await interaction.edit_original_response(content=err_content, view=self)
                                return
                            raise

            final_content = f"**Hasil Regenerate:**\n\n{(new_reply or 'Tidak ada respons.')}"[:DISCORD_MSG_CHUNK_LIMIT]
            if interaction.message is not None:
                await interaction.message.edit(content=final_content, view=self)
            else:
                await interaction.edit_original_response(content=final_content, view=self)
        except Exception as exc:
            logging.exception("Regenerate gagal untuk scope %s", scope_key)
            err_content = f"⚠️ Regenerate gagal: `{safe_exc_text(exc)}`"[:1990]
            if interaction.message is not None:
                await interaction.message.edit(content=err_content, view=self)
            else:
                await interaction.edit_original_response(content=err_content, view=self)

    @discord.ui.button(label="\U0001f4cb Kirim Teks via DM", style=discord.ButtonStyle.primary, custom_id="ai_dm_text")
    async def dm_text_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        state = await self._authorize(interaction)
        if state is None:
            return
        allowed, wait = self.bot_instance.rate_limiter.acquire("dm", interaction.user.id, counts_daily=False)
        if not allowed:
            await reply_ephemeral(interaction, rate_limit_text(wait))
            return
        try:
            await interaction.response.defer(ephemeral=True)  # kirim DM bisa lambat; jangan lewati batas 3 detik Discord
        except Exception:
            pass
        try:
            msg_content = interaction.message.content
            if not msg_content and interaction.message.embeds:
                msg_content = interaction.message.embeds[0].description or "(Embed Gambar)"
            safe_content = scrub_secrets(scrub_base64_text(msg_content or ""))
            await interaction.user.send(f"📥 **Salinan Teks Bot:**\n\n{safe_content}"[:1990])
            await reply_ephemeral(interaction, "✅ Berhasil dikirim ke DM lu!")
        except Exception:
            await reply_ephemeral(interaction, "⚠️ Gagal kirim DM. Pastikan DM Discord lu tidak dikunci!")


class ClouzerBot(commands.Bot):
    _EMBEDDED_IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".gif")

    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents, allowed_mentions=discord.AllowedMentions.none())
        self.http_session: aiohttp.ClientSession | None = None
        self.guild_locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)
        self.last_channel_images: OrderedDict[tuple[int, int, int], tuple[float, list[str]]] = OrderedDict()
        self.cf_rr_index: int = 0
        self.cf_cooldowns: dict[str, float] = {}
        self.image_busy_users: set[int] = set()
        self.user_image_locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
        self.memory_lock = asyncio.Lock()
        self.last_memory_save_error: str | None = None
        self._sync_task: asyncio.Task | None = None
        # --- patch security-hardening-2026-11 ---
        self.rate_limiter = RateLimiter(
            load_rate_rules(),
            daily_limit=RATE_DAILY_LIMIT_PER_USER,
            exempt_ids=RATE_LIMIT_EXEMPT_USER_IDS,
            enabled=RATE_LIMIT_ENABLED,
        )
        self.attachment_semaphore = asyncio.Semaphore(MAX_CONCURRENT_ATTACHMENTS)
        self.ai_semaphore = asyncio.Semaphore(MAX_CONCURRENT_AI_CALLS)
        self.view_states = ViewStateStore(
            VIEW_STATE_FILE,
            max_entries=VIEW_STATE_MAX_ENTRIES,
            max_snapshots=VIEW_STATE_MAX_SNAPSHOTS,
            live_media=VIEW_STATE_LIVE_MEDIA,
            snapshot_chars=VIEW_STATE_SNAPSHOT_CHARS,
            retention_seconds=VIEW_STATE_RETENTION_SECONDS,
        )
        self.view_busy: set[int] = set()
        self.persistent_view: "AIResponseView | None" = None
        self.memory_data = self.load_memory()

    def is_user_image_busy(self, user_id: int) -> bool:
        return user_id in self.image_busy_users

    def user_image_queue(self, user_id: int):
        class _QueueCtx:
            def __init__(self, bot_ref: "ClouzerBot", uid: int):
                self.bot_ref = bot_ref
                self.uid = uid
                self.lock = bot_ref.user_image_locks[uid]

            async def __aenter__(self):
                acquired = False
                try:
                    await self.lock.acquire()
                    acquired = True
                    # Set mutation is atomic on the event loop; no second await
                    # is needed after acquiring the per-user lock.
                    self.bot_ref.image_busy_users.add(self.uid)
                    return self
                except BaseException:
                    if acquired and self.lock.locked():
                        self.lock.release()
                    raise

            async def __aexit__(self, exc_type, exc, tb):
                # Keep cleanup synchronous so cancellation cannot strand either
                # the busy marker or the per-user lock.
                self.bot_ref.image_busy_users.discard(self.uid)
                if self.lock.locked():
                    self.lock.release()

        return _QueueCtx(self, user_id)

    def _cf_account_key(self, acc: dict[str, str]) -> str:
        return f"{acc.get('id', '')}:{acc.get('label', '')}"

    def _cleanup_channel_images(self) -> None:
        now = time.monotonic()
        expired = [
            k for k, (ts, _) in self.last_channel_images.items()
            if (now - ts) > IMAGE_CONTEXT_TTL_SECONDS
        ]
        for k in expired:
            self.last_channel_images.pop(k, None)
        while len(self.last_channel_images) > max(1, IMAGE_CONTEXT_MAX_ENTRIES):
            self.last_channel_images.popitem(last=False)

    def set_last_user_image(self, guild_id: int, channel_id: int, user_id: int, images: list[str]) -> None:
        if not images or not channel_id:
            return
        self._cleanup_channel_images()
        key = (guild_id, channel_id, user_id)
        self.last_channel_images[key] = (time.monotonic(), images)
        self.last_channel_images.move_to_end(key, last=True)
        self._cleanup_channel_images()

    def get_last_user_image(self, guild_id: int, channel_id: int, user_id: int) -> list[str] | None:
        if not channel_id:
            return None
        self._cleanup_channel_images()
        key = (guild_id, channel_id, user_id)
        item = self.last_channel_images.get(key)
        if item is None:
            return None
        self.last_channel_images.move_to_end(key, last=True)
        return item[1]

    def _get_rotated_cf_accounts(self) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
        total = len(CF_ACCOUNTS)
        if total == 0:
            return [], []
        start = self.cf_rr_index % total
        self.cf_rr_index = (self.cf_rr_index + 1) % total
        rotated = CF_ACCOUNTS[start:] + CF_ACCOUNTS[:start]
        now = time.monotonic()
        ready = [acc for acc in rotated if now >= self.cf_cooldowns.get(self._cf_account_key(acc), 0.0)]
        cooling = [acc for acc in rotated if now < self.cf_cooldowns.get(self._cf_account_key(acc), 0.0)]
        return ready, cooling

    def _normalize_scope_state(self, raw_state: object) -> dict:
        base = {
            "allowed_channels": [],
            "active_threads": [],
            "auto_channels": [],
            "thread_modes": {},
            "summary": "",
            "messages": [],
            "turn_count": 0,
            "users": {},
        }
        if not isinstance(raw_state, dict):
            return base

        merged = dict(base)
        for k in ["allowed_channels", "active_threads", "auto_channels", "messages"]:
            val = raw_state.get(k)
            if isinstance(val, list):
                merged[k] = scrub_nested_base64(val)

        for k in ["thread_modes", "users"]:
            val = raw_state.get(k)
            if isinstance(val, dict):
                merged[k] = scrub_nested_base64(val)

        # Memory files may outlive code versions or be edited/corrupted. Keep
        # only supported chat roles and well-formed text/image content blocks.
        safe_messages = []
        for message in merged.get("messages", []):
            if not isinstance(message, dict):
                continue
            role = message.get("role")
            if role not in ("user", "assistant"):
                continue
            content = message.get("content", "")
            if isinstance(content, str):
                safe_content = scrub_base64_text(content)
            elif isinstance(content, list):
                safe_content = []
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    block_type = block.get("type")
                    if block_type == "text" and isinstance(block.get("text"), str):
                        safe_content.append({"type": "text", "text": scrub_base64_text(block["text"])})
                    elif block_type == "image_url":
                        image_obj = block.get("image_url")
                        image_url = image_obj.get("url") if isinstance(image_obj, dict) else None
                        if isinstance(image_url, str) and image_url.startswith(("https://", "http://", "data:image/")):
                            safe_content.append({"type": "image_url", "image_url": {"url": image_url}})
            else:
                continue
            safe_messages.append({"role": role, "content": safe_content})
        merged["messages"] = safe_messages[-MAX_RECENT_MESSAGES:]

        summary_val = raw_state.get("summary")
        if isinstance(summary_val, str):
            merged["summary"] = scrub_base64_text(summary_val)

        turn_val = raw_state.get("turn_count")
        if isinstance(turn_val, int) and not isinstance(turn_val, bool):
            merged["turn_count"] = max(0, turn_val)

        return merged

    def _sanitize_memory_for_disk(self) -> dict:
        sanitized_guilds: dict = {}
        for scope_key, state in self.memory_data.get("guilds", {}).items():
            copied_state = self._normalize_scope_state(state)
            clean_msgs = []
            for m in copied_state.get("messages", []):
                if not isinstance(m, dict):
                    continue
                content = m.get("content", "")
                if isinstance(content, list):
                    text_parts = []
                    img_count = 0
                    for block in content:
                        if not isinstance(block, dict):
                            continue
                        if block.get("type") == "text" and block.get("text"):
                            text_parts.append(scrub_base64_text(str(block["text"])))
                        elif block.get("type") == "image_url":
                            img_count += 1
                    merged = "\n".join(text_parts).strip()
                    if img_count:
                        merged = f"{merged}\n[{img_count} gambar dilampirkan]".strip()
                    clean_msgs.append({"role": m.get("role", "user"), "content": scrub_base64_text(merged)})
                else:
                    clean_msgs.append({"role": m.get("role", "user"), "content": scrub_base64_text(str(content))})

            copied_state["messages"] = clean_msgs[-MAX_RECENT_MESSAGES:]
            sanitized_guilds[str(scope_key)] = copied_state
        return {"guilds": sanitized_guilds}

    def _scrub_loaded_scope(self, state: dict) -> dict:
        """Bersihkan secret yang mungkin tersimpan di memory.json versi lama saat dimuat."""
        for message in state.get("messages", []):
            content = message.get("content")
            if isinstance(content, str):
                message["content"] = scrub_secrets(content)
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        block["text"] = scrub_secrets(str(block.get("text", "")))
        if isinstance(state.get("summary"), str):
            state["summary"] = scrub_secrets(state["summary"])
        return state

    def get_response_view(self) -> "AIResponseView":
        """Instance view persisten yang dipakai bersama oleh semua pesan jawaban AI."""
        if self.persistent_view is None:
            self.persistent_view = AIResponseView(self)
        return self.persistent_view
    @staticmethod
    def _fit_history_budget(history: list[dict]) -> list[dict]:
        """Buang riwayat paling lama bila total karakter melebihi PROMPT_HISTORY_MAX_CHARS.

        Pesan terbaru selalu dipertahankan. Mencegah prompt membengkak (biaya API & error panjang konteks).
        """
        kept: list[dict] = []
        total = 0
        for message in reversed(history):
            size = message_char_len(message)
            if kept and total + size > PROMPT_HISTORY_MAX_CHARS:
                break
            kept.append(message)
            total += size
        kept.reverse()
        return kept

    def load_memory(self) -> dict:
        if os.path.exists(MEMORY_FILE) and os.path.getsize(MEMORY_FILE) > MAX_MEMORY_FILE_BYTES:
            # Fail closed: jangan memulai dengan state kosong lalu menimpa file memori lama.
            raise RuntimeError(
                "memory.json melewati batas 20 MB. Bot dihentikan agar data lama tidak tertimpa; backup dan periksa file tersebut."
            )
        if os.path.exists(MEMORY_FILE):
            try:
                try:
                    os.chmod(MEMORY_FILE, 0o600)
                except OSError:
                    logging.warning("Tidak dapat mengatur permission memory.json ke 0600 saat load")
                with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    raw_guilds = data.get("guilds") if isinstance(data.get("guilds"), dict) else data
                    if isinstance(raw_guilds, dict):
                        migrated: dict = {}
                        for scope_key, st in raw_guilds.items():
                            if str(scope_key) == "guilds" and not isinstance(st, dict):
                                continue
                            migrated[str(scope_key)] = self._scrub_loaded_scope(self._normalize_scope_state(st))
                        return {"guilds": migrated}
            except Exception as exc:
                logging.exception("Gagal memuat memory dari %s: %s", MEMORY_FILE, exc)
        return {"guilds": {}}

    async def save_memory(self):
        async with self.memory_lock:
            tmp_file = f"{MEMORY_FILE}.tmp"
            try:
                disk_payload = self._sanitize_memory_for_disk()
                serialized = json.dumps(disk_payload, ensure_ascii=False, indent=2)
                if len(serialized.encode("utf-8")) > MAX_MEMORY_FILE_BYTES:
                    raise ValueError("memory.json melewati batas ukuran aman; file lama dipertahankan")
                fd = os.open(tmp_file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
                try:
                    os.chmod(tmp_file, 0o600)
                except OSError:
                    pass
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(serialized)
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp_file, MEMORY_FILE)
                try:
                    os.chmod(MEMORY_FILE, 0o600)
                except OSError:
                    logging.warning("Tidak dapat mengatur permission memory.json ke 0600")
                self.last_memory_save_error = None
            except Exception as exc:
                self.last_memory_save_error = f"{type(exc).__name__}: {exc}"
                logging.exception("Gagal menyimpan memory ke %s", MEMORY_FILE)
                try:
                    if os.path.exists(tmp_file):
                        os.remove(tmp_file)
                except Exception:
                    pass

    def get_scope_key(
        self,
        guild: discord.Guild | None,
        user_id: int | None = None,
        channel_id: int | None = None,
    ) -> str:
        ch_part = channel_id or 0
        if guild is not None:
            return f"guild_{guild.id}_ch_{ch_part}_user_{user_id or 0}"
        return f"dm_{user_id or 0}_ch_{ch_part}"

    def get_guild_state(
        self,
        guild: discord.Guild | None,
        user_id: int | None = None,
        channel_id: int | None = None,
    ) -> dict:
        key = self.get_scope_key(guild, user_id, channel_id)
        state = self.memory_data["guilds"].get(key)
        if not isinstance(state, dict):
            state = self._normalize_scope_state(state if state is not None else {})
            self.memory_data["guilds"][key] = state
        return state

    def is_channel_allowed(self, channel: discord.abc.Messageable | None, guild: discord.Guild | None) -> bool:
        if guild is None:
            return True
        if channel is None:
            return False
        state = self.get_guild_state(guild)
        base_id = channel.parent_id if isinstance(channel, discord.Thread) else getattr(channel, "id", None)
        return base_id in state["allowed_channels"]

    def has_any_allowed_channel(self, guild: discord.Guild | None) -> bool:
        if guild is None:
            return True
        state = self.get_guild_state(guild)
        return any(guild.get_channel(cid) is not None for cid in state["allowed_channels"])

    async def generate_cloudflare_image(
        self,
        prompt: str,
        source_images: list[str] | None = None,
        aspect_ratio: str | None = None,
    ) -> tuple[bytes, str, str, str]:
        if not CF_ACCOUNTS:
            raise RuntimeError("CF_ACCOUNTS_JSON belum diatur di Environment")

        model_id = CF_EDIT_MODEL if source_images else CF_IMAGE_MODEL
        safe_prompt = sanitize_image_prompt(prompt, max_len=1500)
        target_w, target_h, ratio_label = resolve_image_dimensions(aspect_ratio, prompt, source_images)
        ready_accounts, _ = self._get_rotated_cf_accounts()
        candidates = ready_accounts
        if not candidates:
            wait_left = min(
                (max(0.0, until - time.monotonic()) for until in self.cf_cooldowns.values()),
                default=0.0,
            )
            raise RuntimeError(
                f"Semua akun Cloudflare sedang cooldown (fail-fast aktif). Coba lagi sekitar {wait_left:.0f} detik."
            )
        last_err = ""

        for acc in candidates:
            acc_key = self._cf_account_key(acc)
            url = f"https://api.cloudflare.com/client/v4/accounts/{acc['id']}/ai/run/{model_id}"
            auth_headers = {"Authorization": f"Bearer {acc['token']}"}

            if source_images:
                if len(source_images) > 1 and "flux-2" not in model_id.lower():
                    raise RuntimeError("Model edit yang dipilih hanya menerima satu gambar sumber. Atur CF_EDIT_MODEL ke model Flux 2 untuk multi-gambar.")
                normalized_sources = []
                is_flux2 = "flux-2" in model_id.lower()
                source_max_size = (768, 768) if is_flux2 else (1536, 1536)
                for source_index, source_url in enumerate(source_images[:4]):
                    _, b64_data = parse_data_url(source_url)
                    raw_bytes = base64.b64decode(b64_data, validate=True)
                    if len(raw_bytes) > 12 * 1024 * 1024:
                        raise RuntimeError(f"Gambar sumber ke-{source_index + 1} melebihi 12 MB.")
                    with Image.open(io.BytesIO(raw_bytes)) as src_probe:
                        src_probe.verify()
                    with Image.open(io.BytesIO(raw_bytes)) as pil_src:
                        pil_img = pil_src.convert("RGB")
                    pil_img.thumbnail(source_max_size)
                    png_buf = io.BytesIO()
                    pil_img.save(png_buf, format="PNG")
                    normalized_sources.append(png_buf.getvalue())

                if is_flux2:
                    form = aiohttp.FormData()
                    form.add_field("prompt", safe_prompt)
                    form.add_field("width", str(target_w))
                    form.add_field("height", str(target_h))
                    for source_index, png_bytes in enumerate(normalized_sources):
                        form.add_field(f"input_image_{source_index}", png_bytes, filename=f"source_{source_index + 1}.png", content_type="image/png")
                    req_kwargs = {"headers": auth_headers, "data": form}
                else:
                    pil_img = Image.open(io.BytesIO(normalized_sources[0])).convert("RGB")
                    pil_small = pil_img.copy()
                    pil_small.thumbnail((768, 768))
                    small_buf = io.BytesIO()
                    pil_small.save(small_buf, format="PNG")
                    payload = {
                        "prompt": safe_prompt,
                        "image": list(small_buf.getvalue()),
                        "width": target_w,
                        "height": target_h,
                        "strength": 0.65,
                        "num_steps": 20,
                    }
                    req_kwargs = {
                        "headers": {**auth_headers, "Content-Type": "application/json"},
                        "json": payload,
                    }
            else:
                if "flux-2" in model_id.lower():
                    form = aiohttp.FormData()
                    form.add_field("prompt", safe_prompt)
                    form.add_field("width", str(target_w))
                    form.add_field("height", str(target_h))
                    form.add_field("steps", "20")
                    req_kwargs = {"headers": auth_headers, "data": form}
                elif "lucid-origin" in model_id.lower():
                    payload = {
                        "prompt": safe_prompt,
                        "width": target_w,
                        "height": target_h,
                        "steps": 25,
                        "guidance": 4.5,
                    }
                    req_kwargs = {
                        "headers": {**auth_headers, "Content-Type": "application/json"},
                        "json": payload,
                    }
                else:
                    payload = {
                        "prompt": safe_prompt,
                        "width": target_w,
                        "height": target_h,
                        "steps": 6,
                    }
                    req_kwargs = {
                        "headers": {**auth_headers, "Content-Type": "application/json"},
                        "json": payload,
                    }

            try:
                async with self.http_session.post(
                    url,
                    timeout=aiohttp.ClientTimeout(total=120),
                    **req_kwargs,
                ) as resp:
                    content_type = resp.headers.get("Content-Type", "").lower()
                    if resp.status != 200:
                        err_bytes = await read_limited_stream(resp.content, 64 * 1024)
                        err_text = err_bytes.decode("utf-8", errors="replace")
                        self.cf_cooldowns[acc_key] = time.monotonic() + CF_COOLDOWN_SECONDS
                        last_err = f"{acc['label']} HTTP {resp.status}: {err_text[:350]}"
                        continue

                    response_limit = 20 * 1024 * 1024 if "application/json" in content_type else MAX_OUTPUT_IMAGE_BYTES
                    response_body = await read_limited_stream(resp.content, response_limit)
                    if "application/json" in content_type:
                        data = json.loads(response_body.decode("utf-8"))
                        b64_img = data.get("result", {}).get("image")
                        if not b64_img:
                            self.cf_cooldowns[acc_key] = time.monotonic() + CF_COOLDOWN_SECONDS
                            last_err = f"{acc['label']} JSON tanpa gambar"
                            continue
                        raw_out = base64.b64decode(b64_img)
                    else:
                        raw_out = response_body

                    valid_bytes, out_filename, out_mime = validate_and_normalize_image_bytes(raw_out)
                    self.cf_cooldowns.pop(acc_key, None)
                    short_model = model_id.split("/")[-1]
                    label = f"Cloudflare AI [{acc['label']}] ({short_model}{' Edit' if source_images else ''} | {ratio_label})"
                    return valid_bytes, out_filename, out_mime, label
            except Exception as exc:
                self.cf_cooldowns[acc_key] = time.monotonic() + CF_COOLDOWN_SECONDS
                last_err = f"{acc['label']} Error: {exc}"
                continue

        raise RuntimeError(last_err or "Semua akun Cloudflare gagal")

    async def generate_pollinations_flux(self, prompt: str, width: int = 1024, height: int = 1024) -> tuple[bytes, str, str]:
        compact_prompt = sanitize_image_prompt(prompt, max_len=450)
        q = urllib.parse.quote(compact_prompt)
        seed = random.randint(1, 999999999)
        image_url = f"https://image.pollinations.ai/prompt/{q}?model=flux&width={width}&height={height}&seed={seed}&nologo=true"
        async with self.http_session.get(
            image_url,
            timeout=aiohttp.ClientTimeout(total=90),
        ) as resp:
            if resp.status != 200:
                raise RuntimeError(f"Pollinations FLUX HTTP {resp.status}")
            raw_bytes = await read_limited_stream(resp.content, MAX_OUTPUT_IMAGE_BYTES)
        valid_bytes, out_filename, out_mime = validate_and_normalize_image_bytes(raw_bytes)
        return valid_bytes, out_filename, out_mime

    async def generate_or_edit_image(
        self,
        prompt: str,
        source_images: list[str] | None = None,
        aspect_ratio: str | None = None,
    ) -> tuple[bytes, str, str, str]:
        if source_images:
            try:
                return await self.generate_cloudflare_image(prompt, source_images=source_images, aspect_ratio=aspect_ratio)
            except Exception as exc:
                raise RuntimeError(f"Edit gambar (Klein 4B) gagal di semua akun Cloudflare: {exc}") from exc

        cf_error = ""
        if CF_ACCOUNTS:
            try:
                return await self.generate_cloudflare_image(prompt, source_images=None, aspect_ratio=aspect_ratio)
            except Exception as exc:
                cf_error = f"{exc}"

        target_w, target_h, ratio_label = resolve_image_dimensions(aspect_ratio, prompt, None)
        img_bytes, out_filename, out_mime = await self.generate_pollinations_flux(prompt, width=target_w, height=target_h)
        note = f" (CF fallback: {cf_error[:220]})" if cf_error else " (tanpa CF Token)"
        return img_bytes, out_filename, out_mime, f"Pollinations FLUX [{ratio_label}]{note}"

    def _wrap_doc_content(self, label: str, filename: str, body: str) -> str:
        return f"\n\n--- KONTEN {label} ({filename}) ---\n{body}\n------------------------------------------\n"

    def _validate_zip_archive(self, raw_bytes: bytes) -> zipfile.ZipFile:
        """Open and preflight a ZIP archive before any parser decompresses it.

        Caller owns and must close the returned ZipFile. Raises ValueError or
        BadZipFile for malformed, encrypted, or resource-excessive archives.
        """
        zf = zipfile.ZipFile(io.BytesIO(raw_bytes))
        try:
            infos = zf.infolist()
            if len(infos) > ZIP_MAX_ENTRIES:
                raise ValueError(f"arsip memiliki terlalu banyak entri ({len(infos)} > {ZIP_MAX_ENTRIES})")
            total_size = 0
            for info in infos:
                if info.is_dir():
                    continue
                if info.flag_bits & 0x1:
                    raise ValueError("arsip ZIP terenkripsi tidak didukung")
                if info.file_size > ZIP_MAX_ENTRY_UNCOMPRESSED:
                    raise ValueError(f"entri ZIP terlalu besar: {info.filename[:100]}")
                total_size += info.file_size
                if total_size > ZIP_MAX_TOTAL_UNCOMPRESSED:
                    raise ValueError("total ukuran hasil ekstraksi ZIP melewati batas keamanan")
                if info.file_size > 1024 * 1024:
                    ratio = info.file_size / max(info.compress_size, 1)
                    if ratio > ZIP_MAX_COMPRESSION_RATIO:
                        raise ValueError(f"rasio kompresi ZIP mencurigakan pada {info.filename[:100]}")
            return zf
        except Exception:
            zf.close()
            raise

    def _extract_zip_media_images(
        self,
        raw_bytes: bytes,
        prefix_dirs: tuple[str, ...],
        max_images: int = MAX_VISION_IMAGES_PER_TURN,
    ) -> list[str]:
        images_out: list[str] = []
        try:
            with self._validate_zip_archive(raw_bytes) as zf:
                media_infos = [
                    info for info in zf.infolist()
                    if not info.is_dir()
                    and info.filename.lower().startswith(prefix_dirs)
                    and info.filename.lower().endswith(self._EMBEDDED_IMAGE_EXTS)
                    and info.file_size <= 15 * 1024 * 1024
                ]
                for info in media_infos[:max_images]:
                    try:
                        with zf.open(info, "r") as stream:
                            mbytes = stream.read(15 * 1024 * 1024 + 1)
                        if not mbytes or len(mbytes) > 15 * 1024 * 1024:
                            continue
                        data_url = self._compress_image_bytes_to_data_url(mbytes)
                        images_out.append(data_url)
                    except Exception as exc:
                        logging.warning("Embedded image skipped (%s): %s", info.filename[:100], type(exc).__name__)
        except Exception as exc:
            logging.warning("Embedded ZIP images unavailable: %s", type(exc).__name__)
        return images_out

    def extract_docx_content(self, docx_bytes: bytes, filename: str) -> tuple[str, list[str]]:
        try:
            with self._validate_zip_archive(docx_bytes):
                pass
        except Exception as exc:
            return f"\n\n[DOCX {filename} ditolak: arsip tidak valid atau melewati batas keamanan ({type(exc).__name__}: {exc}).]\n", []
        media_imgs = self._extract_zip_media_images(docx_bytes, ("word/media/",))
        if docx is None:
            warn = (
                f"\n\n[File DOCX: {filename} terdeteksi, tetapi library 'python-docx' belum terpasang di server. "
                f"Tambahkan 'python-docx' ke requirements.txt lalu restart untuk membaca isi dokumen.]\n"
            )
            return warn, media_imgs

        doc = docx.Document(io.BytesIO(docx_bytes))
        parts: list[str] = []
        total_chars = 0
        max_chars = 25000

        for p in doc.paragraphs:
            txt = (p.text or "").strip()
            if not txt:
                continue
            if total_chars + len(txt) + 2 > max_chars:
                rem = max_chars - total_chars
                if rem > 120:
                    parts.append(txt[:rem] + "\n...(teks dipotong karena panjang)")
                break
            parts.append(txt)
            total_chars += len(txt) + 2

        if total_chars < max_chars and doc.tables:
            for t_idx, table in enumerate(doc.tables[:15], start=1):
                rows_txt: list[str] = []
                for row in table.rows[:40]:
                    cells = [re.sub(r"\s+", " ", (c.text or "").strip()) for c in row.cells]
                    if any(cells):
                        rows_txt.append(" | ".join(cells))
                if rows_txt:
                    tbl_block = f"[Tabel {t_idx}]\n" + "\n".join(rows_txt)
                    if total_chars + len(tbl_block) + 2 > max_chars:
                        rem = max_chars - total_chars
                        if rem > 120:
                            parts.append(tbl_block[:rem] + "\n...(tabel dipotong karena panjang)")
                        break
                    parts.append(tbl_block)
                    total_chars += len(tbl_block) + 2

        extracted = "\n\n".join(parts).strip()
        if media_imgs:
            note = f"\n[Terdapat {len(media_imgs)} gambar di dalam DOCX yang ikut dikirim sebagai lampiran visual.]"
            extracted = (extracted + note).strip() if extracted else note.strip()

        if extracted:
            return self._wrap_doc_content("DOCX", filename, extracted), media_imgs
        return self._wrap_doc_content("DOCX", filename, "[File DOCX terbaca namun tidak memiliki teks paragraf atau tabel yang dapat diekstrak.]"), media_imgs

    def extract_pptx_content(self, pptx_bytes: bytes, filename: str) -> tuple[str, list[str]]:
        try:
            with self._validate_zip_archive(pptx_bytes):
                pass
        except Exception as exc:
            return f"\n\n[PPTX {filename} ditolak: arsip tidak valid atau melewati batas keamanan ({type(exc).__name__}: {exc}).]\n", []
        media_imgs = self._extract_zip_media_images(pptx_bytes, ("ppt/media/",))
        max_chars = 25000
        parts: list[str] = []
        total_chars = 0

        if Presentation is not None:
            prs = Presentation(io.BytesIO(pptx_bytes))
            for s_idx, slide in enumerate(prs.slides, start=1):
                slide_lines: list[str] = []
                for shape in slide.shapes:
                    if getattr(shape, "has_text_frame", False) and shape.text_frame:
                        stxt = (shape.text_frame.text or "").strip()
                        if stxt:
                            slide_lines.append(stxt)
                    if getattr(shape, "has_table", False) and shape.table:
                        for row in shape.table.rows[:30]:
                            cells = [re.sub(r"\s+", " ", (c.text or "").strip()) for c in row.cells]
                            if any(cells):
                                slide_lines.append(" | ".join(cells))
                if slide_lines:
                    block = f"[Slide {s_idx}]\n" + "\n".join(slide_lines)
                    if total_chars + len(block) + 2 > max_chars:
                        rem = max_chars - total_chars
                        if rem > 120:
                            parts.append(block[:rem] + "\n...(teks dipotong karena panjang)")
                        break
                    parts.append(block)
                    total_chars += len(block) + 2
        else:
            try:
                with zipfile.ZipFile(io.BytesIO(pptx_bytes)) as zf:
                    slide_names = sorted(
                        [n for n in zf.namelist() if re.match(r"^ppt/slides/slide\d+\.xml$", n)],
                        key=lambda x: int(re.search(r"(\d+)", x).group(1)),
                    )
                    for idx, sname in enumerate(slide_names, start=1):
                        root = safe_xml_fromstring(zf.read(sname))
                        texts = [el.text.strip() for el in root.iter() if el.tag.endswith("}t") and el.text and el.text.strip()]
                        if texts:
                            block = f"[Slide {idx}]\n" + "\n".join(texts)
                            if total_chars + len(block) + 2 > max_chars:
                                rem = max_chars - total_chars
                                if rem > 120:
                                    parts.append(block[:rem] + "\n...(teks dipotong karena panjang)")
                                break
                            parts.append(block)
                            total_chars += len(block) + 2
            except Exception as exc:
                return f"\n\n[File PPTX {filename} terdeteksi, namun gagal dibaca ({type(exc).__name__}: {exc}). Tambahkan 'python-pptx' ke requirements.txt untuk hasil optimal.]\n", media_imgs

        extracted = "\n\n".join(parts).strip()
        if media_imgs:
            note = f"\n[Terdapat {len(media_imgs)} gambar di dalam PPTX yang ikut dikirim sebagai lampiran visual.]"
            extracted = (extracted + note).strip() if extracted else note.strip()

        if extracted:
            return self._wrap_doc_content("PPTX", filename, extracted), media_imgs
        return self._wrap_doc_content("PPTX", filename, "[File PPTX terbaca namun tidak mengandung teks slide yang dapat diekstrak.]"), media_imgs

    def extract_xlsx_content(self, xlsx_bytes: bytes, filename: str) -> tuple[str, list[str]]:
        try:
            with self._validate_zip_archive(xlsx_bytes):
                pass
        except Exception as exc:
            return f"\n\n[XLSX {filename} ditolak: arsip tidak valid atau melewati batas keamanan ({type(exc).__name__}: {exc}).]\n", []
        media_imgs = self._extract_zip_media_images(xlsx_bytes, ("xl/media/",))
        if openpyxl is None:
            warn = (
                f"\n\n[File XLSX: {filename} terdeteksi, tetapi library 'openpyxl' belum terpasang di server. "
                f"Tambahkan 'openpyxl' ke requirements.txt lalu restart untuk membaca isi spreadsheet.]\n"
            )
            return warn, media_imgs

        wb = openpyxl.load_workbook(io.BytesIO(xlsx_bytes), data_only=True, read_only=True)
        try:
            parts: list[str] = []
            total_chars = 0
            max_chars = 25000

            for sheet_name in wb.sheetnames[:15]:
                ws = wb[sheet_name]
                rows_out: list[str] = []
                for r_idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
                    if r_idx > 120:
                        rows_out.append("...(baris lanjutan dipotong)")
                        break
                    cells = [re.sub(r"\s+", " ", str(v).strip()) for v in row[:25] if v is not None and str(v).strip() != ""]
                    if cells:
                        rows_out.append(f"B{r_idx}: " + " | ".join(cells))
                if rows_out:
                    block = f"[Sheet: {sheet_name}]\n" + "\n".join(rows_out)
                    if total_chars + len(block) + 2 > max_chars:
                        rem = max_chars - total_chars
                        if rem > 120:
                            parts.append(block[:rem] + "\n...(data sheet dipotong karena panjang)")
                        break
                    parts.append(block)
                    total_chars += len(block) + 2

            extracted = "\n\n".join(parts).strip()
            if media_imgs:
                note = f"\n[Terdapat {len(media_imgs)} gambar di dalam XLSX yang ikut dikirim sebagai lampiran visual.]"
                extracted = (extracted + note).strip() if extracted else note.strip()

            if extracted:
                return self._wrap_doc_content("XLSX", filename, extracted), media_imgs
            return self._wrap_doc_content("XLSX", filename, "[File XLSX terbaca namun semua sheet kosong.]"), media_imgs
        finally:
            wb.close()

    def extract_rtf_content(self, rtf_bytes: bytes, filename: str) -> str:
        raw = rtf_bytes.decode("utf-8", errors="ignore")
        text = re.sub(r"\\par[d]?\b", "\n", raw)
        text = re.sub(r"\\'[0-9a-fA-F]{2}", " ", text)
        text = re.sub(r"\\[a-zA-Z]+-?\d*\s?", " ", text)
        text = text.replace("{", "").replace("}", "")
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n\s*\n+", "\n\n", text).strip()[:25000]
        if text:
            return self._wrap_doc_content("RTF", filename, text)
        return self._wrap_doc_content("RTF", filename, "[File RTF tidak mengandung teks yang dapat dibaca.]")

    def extract_zip_office_or_epub_content(self, raw_bytes: bytes, filename: str, ext: str) -> str:
        parts: list[str] = []
        total_chars = 0
        max_chars = 25000

        try:
            with self._validate_zip_archive(raw_bytes) as zf:
                if ext in {".odt", ".ods", ".odp"}:
                    target_xml = "content.xml"
                    if target_xml in zf.namelist():
                        root = safe_xml_fromstring(zf.read(target_xml))
                        texts = [el.text.strip() for el in root.iter() if el.text and el.text.strip()]
                        joined = " | ".join(texts)
                        if joined:
                            parts.append(joined[:max_chars])
                elif ext == ".epub":
                    html_files = sorted([n for n in zf.namelist() if n.lower().endswith((".xhtml", ".html", ".htm"))])
                    for hname in html_files[:20]:
                        parser = _SimpleHTMLTextExtractor()
                        with zf.open(hname, "r") as stream:
                            html_bytes = stream.read(2 * 1024 * 1024 + 1)
                        if len(html_bytes) > 2 * 1024 * 1024:
                            continue
                        parser.feed(html_bytes.decode("utf-8", errors="ignore"))
                        htxt = parser.get_text().strip()
                        if htxt:
                            block = f"[{hname}]\n{htxt}"
                            if total_chars + len(block) + 2 > max_chars:
                                rem = max_chars - total_chars
                                if rem > 120:
                                    parts.append(block[:rem] + "\n...(konten dipotong karena panjang)")
                                break
                            parts.append(block)
                            total_chars += len(block) + 2
        except Exception as exc:
            return f"\n\n[Gagal membaca arsip {filename} ({ext}): {type(exc).__name__}: {exc}]\n"

        extracted = "\n\n".join(parts).strip()
        if extracted:
            return self._wrap_doc_content(ext.lstrip(".").upper(), filename, extracted)
        return self._wrap_doc_content(ext.lstrip(".").upper(), filename, f"[File {filename} terbaca namun tidak memiliki teks yang dapat diekstrak.]")

    def extract_design_file_content(self, raw_bytes: bytes, filename: str, ext: str) -> str:
        if ext == ".svg":
            try:
                root = safe_xml_fromstring(raw_bytes)
                texts = [re.sub(r"\s+", " ", el.text).strip() for el in root.iter() if el.text and el.text.strip()]
                w = root.attrib.get("width", "?")
                h = root.attrib.get("height", "?")
                vb = root.attrib.get("viewBox", "?")
                summary_lines = [f"Dimensi SVG: width={w}, height={h}, viewBox={vb}"]
                if texts:
                    summary_lines.append("Teks di dalam SVG:\n" + "\n".join(texts[:150]))
                else:
                    summary_lines.append("[Tidak ada elemen teks di dalam SVG; file berisi elemen vektor/grafis.]")
                return self._wrap_doc_content("SVG", filename, "\n\n".join(summary_lines)[:25000])
            except Exception as exc:
                return f"\n\n[Gagal memparse file SVG {filename}: {type(exc).__name__}: {exc}]\n"

        if fitz is not None and ext in {".ai", ".eps"}:
            try:
                doc = fitz.open(stream=raw_bytes, filetype="pdf" if ext == ".ai" else "eps")
                try:
                    pages_txt = []
                    for i, page in enumerate(doc[:10], start=1):
                        pt = page.get_text("text").strip()
                        if pt:
                            pages_txt.append(f"[Halaman/Layer {i}]\n{pt}")
                    if pages_txt:
                        return self._wrap_doc_content(ext.lstrip(".").upper(), filename, "\n\n".join(pages_txt)[:25000])
                finally:
                    doc.close()
            except Exception:
                pass

        printable = re.findall(r"[A-Za-z0-9_.,:;!?()/@#&+\-\s]{4,}", raw_bytes.decode("latin-1", errors="ignore"))
        cleaned_lines = [re.sub(r"\s+", " ", s).strip() for s in printable if len(re.sub(r"\s+", " ", s).strip()) >= 4]
        filtered = [ln for ln in cleaned_lines if not ln.startswith(("%%", "/Subtype", "/Type", "/Filter", "endobj", "stream"))][:80]
        body = f"Info file desain {filename} ({ext}, {round(len(raw_bytes) / 1024, 1)} KB)."
        if filtered:
            body += "\nCuplikan string/label terbaca:\n" + "\n".join(filtered)
        else:
            body += "\n[Konten grafis vektor/Adobe biner terdeteksi; teks editable tidak ditemukan secara langsung.]"
        return self._wrap_doc_content(ext.lstrip(".").upper(), filename, body[:25000])

    async def transcribe_audio_bytes(self, audio_bytes: bytes, filename: str) -> str:
        if not audio_bytes:
            return f"\n\n[File audio {filename} kosong.]\n"
        if not CF_ACCOUNTS or self.http_session is None:
            return f"\n\n[File audio {filename} terdeteksi, tetapi CF_ACCOUNTS_JSON belum siap untuk transkripsi.]\n"

        model_id = (CF_AUDIO_MODEL or "@cf/openai/whisper-large-v3-turbo").strip()
        ready_accounts, _ = self._get_rotated_cf_accounts()
        if not ready_accounts:
            wait_left = min(
                (max(0.0, until - time.monotonic()) for until in self.cf_cooldowns.values()),
                default=0.0,
            )
            return (
                f"\n\n[File audio {filename} terdeteksi, tetapi semua akun Cloudflare sedang cooldown. "
                f"Coba lagi sekitar {wait_left:.0f} detik.]\n"
            )

        audio_b64 = base64.b64encode(audio_bytes).decode("ascii")
        payload = {"audio": audio_b64}
        last_err = ""

        for acc in ready_accounts:
            acc_key = self._cf_account_key(acc)
            url = f"https://api.cloudflare.com/client/v4/accounts/{acc['id']}/ai/run/{model_id}"
            headers = {
                "Authorization": f"Bearer {acc['token']}",
                "Content-Type": "application/json",
            }
            logging.info(
                "CF Audio transcription request: account=%s model=%s filename=%s size=%d",
                acc["label"],
                model_id,
                filename,
                len(audio_bytes),
            )
            try:
                async with self.http_session.post(
                    url,
                    headers=headers,
                    json=payload,
                    timeout=aiohttp.ClientTimeout(total=120),
                ) as resp:
                    response_bytes = await read_limited_stream(resp.content, 1024 * 1024)
                    raw_text = response_bytes.decode("utf-8", errors="replace")
                    if resp.status != 200:
                        self.cf_cooldowns[acc_key] = time.monotonic() + CF_COOLDOWN_SECONDS
                        last_err = f"{acc['label']} HTTP {resp.status}: {raw_text[:250]}"
                        continue

                    transcript = ""
                    try:
                        parsed = json.loads(raw_text)
                        res_obj = parsed.get("result") if isinstance(parsed, dict) else None
                        if isinstance(res_obj, dict):
                            transcript = str(res_obj.get("text") or "").strip()
                        elif isinstance(parsed, dict):
                            transcript = str(parsed.get("text") or "").strip()
                    except Exception:
                        transcript = raw_text.strip()

                    self.cf_cooldowns.pop(acc_key, None)
                    if transcript:
                        return (
                            f"\n\n--- TRANSKRIP AUDIO ({filename} | {acc['label']}) ---\n"
                            f"{transcript[:25000]}\n"
                            f"------------------------------------------\n"
                        )
                    return f"\n\n[File audio {filename} diproses di {acc['label']}, tetapi hasil transkripsi kosong.]\n"
            except Exception as exc:
                self.cf_cooldowns[acc_key] = time.monotonic() + CF_COOLDOWN_SECONDS
                last_err = f"{acc['label']} Error: {type(exc).__name__}: {exc}"
                continue

        return f"\n\n[Gagal mentranskripsi audio {filename} di semua akun Cloudflare: {last_err or 'unknown error'}]\n"

    def extract_pdf_content(self, pdf_bytes: bytes, filename: str) -> tuple[str, list[str]]:
        if fitz is None:
            warn = (
                f"\n\n[File PDF: {filename} terdeteksi, tetapi library 'pymupdf' belum terpasang di server. "
                f"Isi PDF tidak dapat dibaca otomatis saat ini.]\n"
            )
            return warn, []

        try:
            doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        except Exception as exc:
            return f"\n\n[Gagal membuka PDF {filename}: {type(exc).__name__}: {exc}]\n", []

        try:
            total_pages = len(doc)
            if total_pages == 0:
                return f"\n\n[PDF {filename} kosong dan tidak memiliki halaman.]\n", []

            text_parts: list[str] = []
            rendered_pages: list[str] = []
            total_chars = 0
            max_text_pages = min(total_pages, 25)
            max_render_pages = min(total_pages, MAX_VISION_IMAGES_PER_TURN)
            rendered_page_numbers: list[int] = []
            skipped_render_pages = 0

            for i in range(max_text_pages):
                page = doc[i]
                page_text = (page.get_text("text") or "").strip()
                # A tiny text layer on an otherwise scanned page is not enough
                # to consider the page fully represented; send that page visually.
                if len(page_text) >= 40:
                    block = f"[Halaman {i + 1}]\n{page_text}"
                    remaining = 25000 - total_chars
                    if remaining <= 0:
                        skipped_render_pages += max_text_pages - i
                        break
                    if len(block) > remaining:
                        text_parts.append(block[:remaining] + "\n...(teks dipotong karena panjang)")
                        total_chars = 25000
                        skipped_render_pages += max_text_pages - i - 1
                        break
                    text_parts.append(block)
                    total_chars += len(block) + 2
                elif len(rendered_pages) < max_render_pages:
                    try:
                        rect = page.rect
                        page_width = float(rect.width)
                        page_height = float(rect.height)
                        max_render_pixels = min(MAX_IMAGE_PIXELS, 8_000_000)
                        if (
                            not math.isfinite(page_width)
                            or not math.isfinite(page_height)
                            or page_width <= 0
                            or page_height <= 0
                        ):
                            raise ValueError("ukuran halaman PDF tidak valid")
                        render_scale = min(
                            130 / 72,
                            math.sqrt(max_render_pixels / (page_width * page_height)),
                            8192 / max(page_width, page_height),
                        )
                        if not math.isfinite(render_scale) or render_scale <= 0:
                            raise ValueError("skala render PDF tidak valid")
                        pix = page.get_pixmap(matrix=fitz.Matrix(render_scale, render_scale), alpha=False)
                        if pix.width <= 0 or pix.height <= 0 or pix.width * pix.height > max_render_pixels:
                            raise ValueError("hasil render PDF melewati batas piksel")
                        data_url = self._compress_image_bytes_to_data_url(pix.tobytes("png"))
                        rendered_pages.append(data_url)
                        rendered_page_numbers.append(i + 1)
                    except Exception as exc:
                        skipped_render_pages += 1
                        logging.warning("PDF page render failed (%s, page %d): %s", filename, i + 1, type(exc).__name__)
                else:
                    skipped_render_pages += 1

            # Pages beyond the text-page scan cap are explicitly reported rather
            # than silently implying the entire PDF was processed.
            if total_pages > max_text_pages:
                skipped_render_pages += total_pages - max_text_pages

            extracted_text = "\n\n".join(text_parts)
            status_parts = [f"Total {total_pages} halaman"]
            if rendered_page_numbers:
                status_parts.append("halaman scan/visual yang dikirim: " + ", ".join(map(str, rendered_page_numbers)))
            if skipped_render_pages:
                status_parts.append(f"{skipped_render_pages} halaman belum diproses karena batas pemindaian")

            if extracted_text or rendered_pages:
                details = "\n".join(status_parts)
                formatted_text = (
                    f"\n\n--- KONTEN PDF ({filename} | {'; '.join(status_parts)}) ---\n"
                    f"{extracted_text}\n"
                    f"[Catatan ekstraksi: teks diambil per halaman; halaman scan/teks sangat minim dikirim sebagai gambar. {details}]\n"
                    f"------------------------------------------\n"
                )
            else:
                formatted_text = (
                    f"\n\n--- KONTEN PDF ({filename} | {'; '.join(status_parts)}) ---\n"
                    f"[Tidak ada teks yang berhasil diekstrak dan tidak ada halaman yang berhasil dirender. Batas halaman mungkin tercapai atau PDF berisi halaman yang gagal diproses.]\n"
                    f"------------------------------------------\n"
                )
            return formatted_text, rendered_pages
        finally:
            doc.close()

    def _compress_image_bytes_to_data_url(self, raw_bytes: bytes) -> str:
        with Image.open(io.BytesIO(raw_bytes)) as probe:
            probe.verify()
        with Image.open(io.BytesIO(raw_bytes)) as raw_img:
            img = raw_img.convert("RGB")
        img.thumbnail((800, 800))
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=75)
        b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
        return f"data:image/jpeg;base64,{b64}"

    async def download_image_url_to_data_url(self, image_url: str) -> str | None:
        if not image_url or self.http_session is None:
            return None
        try:
            parsed = urllib.parse.urlsplit(image_url)
            if (
                parsed.scheme.lower() != "https"
                or not parsed.hostname
                or parsed.username
                or parsed.password
                or parsed.port not in (None, 443)
            ):
                return None
            host = parsed.hostname.rstrip(".").encode("idna").decode("ascii").lower()
            if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal")):
                return None
            try:
                ipaddress.ip_address(host)
                # Reject IP-literal URLs; only DNS names with pinned public answers are fetched.
                return None
            except ValueError:
                pass

            loop = asyncio.get_running_loop()
            resolved = await loop.getaddrinfo(host, 443, type=socket.SOCK_STREAM)
            pinned_addresses: list[tuple[int, str]] = []
            seen_addresses: set[str] = set()
            for result in resolved:
                family, address = result[0], result[4][0].split("%", 1)[0]
                ip_obj = ipaddress.ip_address(address)
                if not ip_obj.is_global:
                    return None
                if address not in seen_addresses:
                    pinned_addresses.append((family, address))
                    seen_addresses.add(address)
            if not pinned_addresses:
                return None

            class _PinnedResolver(aiohttp.abc.AbstractResolver):
                async def resolve(self, hostname, port=0, family=socket.AF_INET):
                    if hostname.rstrip(".").lower() != host:
                        raise OSError("Hostname mismatch in pinned image resolver")
                    records = []
                    for addr_family, address in pinned_addresses:
                        if family not in (socket.AF_UNSPEC, addr_family):
                            continue
                        records.append({
                            "hostname": hostname,
                            "host": address,
                            "port": port,
                            "family": addr_family,
                            "proto": 0,
                            "flags": 0,
                        })
                    if not records:
                        raise OSError("No vetted public address for image host")
                    return records

                async def close(self):
                    return None

            connector = aiohttp.TCPConnector(resolver=_PinnedResolver(), use_dns_cache=False)
            async with aiohttp.ClientSession(connector=connector) as safe_session:
                async with safe_session.get(
                    image_url,
                    timeout=aiohttp.ClientTimeout(total=25),
                    allow_redirects=False,
                ) as resp:
                    if resp.status != 200:
                        return None
                    raw_bytes = await read_limited_stream(resp.content, 15 * 1024 * 1024)
            if not raw_bytes:
                return None
            return await asyncio.to_thread(self._compress_image_bytes_to_data_url, raw_bytes)
        except Exception:
            return None

    @staticmethod
    def _blocked_attachment_result(filename: str, reason: str) -> tuple[str | None, list[str], list[str], str]:
        safe_name = scrub_secrets(filename or "file")[:120]
        notice = (
            f"\n\n[File {safe_name} TIDAK dibaca: {reason}. Demi keamanan, isinya tidak dikirim ke AI dan tidak disimpan. "
            f"Sampaikan ke pengguna agar menghapus bagian rahasia (token/password/private key) lalu mengirim ulang.]\n"
        )
        return notice, [], [], "blocked"

    async def _read_attachment_checked(self, attachment: discord.Attachment, ext: str) -> bytes:
        """Baca lampiran ke RAM (ukuran sudah dicek per-jenis oleh pemanggil) + validasi signature & ukuran nyata."""
        declared = int(getattr(attachment, "size", 0) or 0)
        data = await attachment.read()
        if declared and len(data) > declared + 4096:
            raise ValueError("ukuran file tidak sesuai metadata Discord")
        problem = check_file_signature(ext, data)
        if problem:
            raise ValueError(problem)
        return data

    async def encode_attachment(self, attachment: discord.Attachment) -> tuple[str | None, list[str], list[str], str]:
        """Pintu masuk tunggal untuk semua lampiran.

        1. Tolak file kredensial/rahasia berdasarkan NAMA, sebelum file dibaca sama sekali.
        2. Batasi jumlah lampiran yang dibaca ke RAM secara bersamaan (semaphore).
        3. Sensor secret pada teks hasil ekstraksi (dan tolak total bila isinya kredensial).
        Parser aslinya tetap ada di _encode_attachment_impl.
        """
        filename = attachment.filename or "file"
        reason = classify_sensitive_filename(filename)
        if reason:
            return self._blocked_attachment_result(filename, reason)

        try:
            await asyncio.wait_for(self.attachment_semaphore.acquire(), timeout=ATTACHMENT_QUEUE_TIMEOUT_SECONDS)
        except asyncio.TimeoutError:
            return (
                f"\n\n[File {scrub_secrets(filename)[:120]} dilewati: bot sedang sibuk memproses lampiran lain. "
                f"Minta pengguna mengirim ulang sebentar lagi.]\n",
                [], [], "busy",
            )
        try:
            text, local_imgs, http_urls, ftype = await self._encode_attachment_impl(attachment)
        finally:
            self.attachment_semaphore.release()

        # Cabang teks sudah dipindai (dan dipotong) di dalam _encode_attachment_impl.
        if text and ftype not in ("text", "blocked"):
            ext = os.path.splitext(filename.lower())[1]
            scan = await asyncio.to_thread(scan_secrets, text, code_mode=ext in CODE_EXTS)
            if scan.blocked:
                return self._blocked_attachment_result(filename, scan.reason)
            text = scan.text
            if scan.hits:
                text += f"\n[Catatan keamanan: {scan.hits} nilai yang tampak seperti rahasia pada {scrub_secrets(filename)[:80]} disensor.]\n"
        return text, local_imgs, http_urls, ftype

    async def _encode_attachment_impl(self, attachment: discord.Attachment) -> tuple[str | None, list[str], list[str], str]:
        """Parser asli tanpa kebijakan keamanan. Jangan dipanggil langsung: pakai encode_attachment()."""
        filename = attachment.filename.lower()
        ext = os.path.splitext(filename)[1]

        if ext in IMAGE_EXTS and attachment.size <= 15 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                local_data_url = await asyncio.to_thread(self._compress_image_bytes_to_data_url, data)
                http_urls = [attachment.url] if attachment.url and attachment.url.startswith(("http://", "https://")) else []
                return None, [local_data_url], http_urls, "image"
            except Exception:
                return f"\n\n[File gambar {attachment.filename} rusak atau gagal dibaca.]\n", [], [], "none"

        elif ext == ".pdf" and attachment.size <= 20 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                pdf_text, pdf_images = await asyncio.to_thread(self.extract_pdf_content, data, attachment.filename)
                return pdf_text, pdf_images, [], "pdf"
            except Exception as e:
                return f"\n\n[Gagal membaca file PDF {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"

        elif ext == ".docx" and attachment.size <= 15 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                docx_text, docx_imgs = await asyncio.to_thread(self.extract_docx_content, data, attachment.filename)
                return docx_text, docx_imgs, [], "docx"
            except Exception as e:
                return f"\n\n[Gagal membaca file DOCX {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"

        elif ext == ".pptx" and attachment.size <= 20 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                pptx_text, pptx_imgs = await asyncio.to_thread(self.extract_pptx_content, data, attachment.filename)
                return pptx_text, pptx_imgs, [], "pptx"
            except Exception as e:
                return f"\n\n[Gagal membaca file PPTX {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"
        elif ext == ".xlsx" and attachment.size <= 20 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                xlsx_text, xlsx_imgs = await asyncio.to_thread(self.extract_xlsx_content, data, attachment.filename)
                return xlsx_text, xlsx_imgs, [], "xlsx"
            except Exception as e:
                return f"\n\n[Gagal membaca file XLSX {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"

        elif ext == ".rtf" and attachment.size <= 10 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                rtf_text = await asyncio.to_thread(self.extract_rtf_content, data, attachment.filename)
                return rtf_text, [], [], "rtf"
            except Exception as e:
                return f"\n\n[Gagal membaca file RTF {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"

        elif ext in {".odt", ".ods", ".odp", ".epub"} and attachment.size <= 20 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                zip_text = await asyncio.to_thread(self.extract_zip_office_or_epub_content, data, attachment.filename, ext)
                return zip_text, [], [], ext.lstrip(".")
            except Exception as e:
                return f"\n\n[Gagal membaca file {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"

        elif ext in {".svg", ".eps", ".ai"} and attachment.size <= 20 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                design_text = await asyncio.to_thread(self.extract_design_file_content, data, attachment.filename, ext)
                return design_text, [], [], ext.lstrip(".")
            except Exception as e:
                return f"\n\n[Gagal membaca file desain {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "document"

        elif ext in AUDIO_EXTS and attachment.size <= 25 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                audio_text = await self.transcribe_audio_bytes(data, attachment.filename)
                return audio_text, [], [], "audio"
            except Exception as e:
                return f"\n\n[Gagal memproses file audio {attachment.filename}: {type(e).__name__}: {e}]\n", [], [], "audio"

        elif ext in (FULL_CONTENT_EXTS - OFFICE_DOC_EXTS) and attachment.size <= 2 * 1024 * 1024:
            try:
                data = await self._read_attachment_checked(attachment, ext)
                text_content = data.decode("utf-8", errors="ignore")
                scan = await asyncio.to_thread(scan_secrets, text_content, code_mode=ext in CODE_EXTS)
                if scan.blocked:
                    return self._blocked_attachment_result(attachment.filename, scan.reason)
                body_text = scan.text
                notes = ""
                if len(body_text) > MAX_TEXT_FILE_CHARS:
                    body_text = body_text[:MAX_TEXT_FILE_CHARS]
                    notes += f"\n...(dipotong: file panjang, hanya {MAX_TEXT_FILE_CHARS:,} karakter pertama yang dikirim)"
                if scan.hits:
                    notes += f"\n[Catatan keamanan: {scan.hits} nilai yang tampak seperti rahasia disensor sebelum dikirim.]"
                formatted = f"\n\n--- KONTEN FILE ({attachment.filename}) ---\n{body_text}{notes}\n------------------------------------------\n"
                return formatted, [], [], "text"
            except Exception:
                return f"\n\n[Gagal membaca konten teks dari file {attachment.filename}.]\n", [], [], "none"

        elif ext in ALL_SUPPORTED_EXTS:
            return (
                f"\n\n[Metadata file: nama={attachment.filename}, ukuran={round(attachment.size / (1024*1024), 2)} MB. "
                f"Catatan: parser isi penuh tersedia untuk gambar, PDF, DOCX, PPTX, XLSX, RTF, ODT/ODS/ODP/EPUB, SVG/EPS/AI, audio, dan file teks/kode.]\n",
                [],
                [],
                "metadata_only",
            )

        return None, [], [], "none"

    async def resolve_replied_images(self, message: discord.Message) -> tuple[list[str], list[str]]:
        ref = message.reference
        if not ref or not ref.message_id:
            return [], []
        replied_msg = ref.resolved if isinstance(ref.resolved, discord.Message) else None
        if replied_msg is None and hasattr(message.channel, "fetch_message"):
            try:
                replied_msg = await message.channel.fetch_message(ref.message_id)
            except Exception:
                replied_msg = None
        if not replied_msg:
            return [], []

        local_imgs: list[str] = []
        http_urls: list[str] = []
        for att in list(replied_msg.attachments)[:MAX_ATTACHMENTS_PER_MESSAGE]:
            if os.path.splitext(att.filename.lower())[1] not in IMAGE_EXTS:
                continue
            _, local_res, http_res, ftype = await self.encode_attachment(att)
            if ftype == "image":
                local_imgs.extend(local_res)
                http_urls.extend(http_res)

        if not local_imgs and replied_msg.embeds:
            for emb in replied_msg.embeds:
                candidate_urls: list[str] = []
                for media_obj in (getattr(emb, "image", None), getattr(emb, "thumbnail", None)):
                    if media_obj is None:
                        continue
                    for attr_name in ("url", "proxy_url"):
                        u = getattr(media_obj, attr_name, None)
                        if isinstance(u, str) and u.startswith(("http://", "https://")) and u not in candidate_urls:
                            candidate_urls.append(u)
                for cand_url in candidate_urls:
                    downloaded_data_url = await self.download_image_url_to_data_url(cand_url)
                    if downloaded_data_url:
                        local_imgs.append(downloaded_data_url)
                        if cand_url not in http_urls:
                            http_urls.append(cand_url)
                        break
                if local_imgs:
                    break

        return local_imgs, http_urls

    def build_messages_payload(
        self,
        guild: discord.Guild | None,
        user_id: int,
        channel_id: int | None = None,
        current_turn_images: list[str] | None = None,
    ) -> list[dict]:
        guild_state = self.get_guild_state(guild, user_id, channel_id)
        messages = [{"role": "system", "content": BASE_SYSTEM_PROMPT}]
        messages.extend(self._fit_history_budget(guild_state["messages"]))

        vision_imgs = [
            u for u in (current_turn_images or [])
            if isinstance(u, str) and u.startswith(("http://", "https://", "data:image/"))
        ][:MAX_VISION_IMAGES_PER_TURN]

        if vision_imgs and messages and messages[-1].get("role") == "user":
            last_msg = messages[-1]
            existing_content = last_msg.get("content", "")
            if isinstance(existing_content, list):
                existing_urls = {
                    b.get("image_url", {}).get("url")
                    for b in existing_content
                    if isinstance(b, dict) and b.get("type") == "image_url"
                }
                new_blocks = list(existing_content)
                for u in vision_imgs:
                    if u not in existing_urls:
                        new_blocks.append({"type": "image_url", "image_url": {"url": u}})
                        existing_urls.add(u)
                capped_blocks = []
                image_count = 0
                for block in new_blocks:
                    if isinstance(block, dict) and block.get("type") == "image_url":
                        if image_count >= MAX_VISION_IMAGES_PER_TURN:
                            continue
                        image_count += 1
                    capped_blocks.append(block)
                messages[-1] = {"role": "user", "content": capped_blocks}
            else:
                blocks = [{"type": "text", "text": str(existing_content)}] + [
                    {"type": "image_url", "image_url": {"url": u}} for u in vision_imgs
                ]
                messages[-1] = {"role": "user", "content": blocks}

        return messages

    def to_responses_input(self, messages: list[dict]) -> tuple[str, list[dict]]:
        instructions = BASE_SYSTEM_PROMPT
        input_items = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                instructions = str(content)
                continue
            if role == "assistant":
                input_items.append({
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": str(content)}],
                })
            else:
                if isinstance(content, list):
                    parts = []
                    for block in content:
                        btype = block.get("type")
                        if btype == "text":
                            parts.append({"type": "input_text", "text": block.get("text", "")})
                        elif btype == "image_url":
                            img_url = block.get("image_url", {}).get("url", "")
                            if img_url and img_url.startswith(("http://", "https://", "data:image/")):
                                parts.append({"type": "input_image", "image_url": img_url})
                    if not parts:
                        parts.append({"type": "input_text", "text": ""})
                    input_items.append({"role": "user", "content": parts})
                else:
                    input_items.append({
                        "role": "user",
                        "content": [{"type": "input_text", "text": str(content)}],
                    })
        return instructions, input_items

    async def setup_hook(self):
        self.http_session = aiohttp.ClientSession()
        # View persisten: satu instance stateless menangani semua tombol Regenerate/DM,
        # termasuk pada pesan lama setelah bot restart.
        self.persistent_view = AIResponseView(self)
        try:
            self.add_view(self.persistent_view)
        except Exception as exc:
            # Jangan diam-diam menjalankan bot dengan tombol yang tampak aktif tetapi tidak persisten.
            raise RuntimeError("Gagal mendaftarkan view persisten Discord; startup dihentikan.") from exc

    async def _run_background_sync(self):
        try:
            await asyncio.sleep(1.5)
            # Semua command dideklarasikan global; sync global saja agar tidak membuat
            # salinan guild yang dapat tampil ganda di server.
            await self.tree.sync()
        except Exception:
            logging.exception("Gagal sinkronisasi slash commands di background")

    def schedule_command_sync(self):
        if self._sync_task is not None and not self._sync_task.done():
            return
        self._sync_task = asyncio.create_task(self._run_background_sync())

    async def sync_commands_to_guilds(self):
        await self._run_background_sync()

    async def close(self):
        if self._sync_task is not None and not self._sync_task.done():
            self._sync_task.cancel()
        await self.save_memory()
        await self.view_states.save()
        if self.http_session and not self.http_session.closed:
            await self.http_session.close()
        await super().close()

    async def run_responses_ai(
        self,
        messages: list[dict],
        target_msg: discord.Message | None,
        mode: str = "fast",
        *,
        allow_tools: bool = True,
        allow_image_tool: bool = True,
        extra_input: list[dict] | None = None,
    ) -> tuple[str, list[dict]]:
        """Pembungkus: batasi panggilan Xingchi paralel & sensor nilai rahasia bot pada output model."""
        async with self.ai_semaphore:
            text, calls = await self._run_responses_ai_impl(
                messages, target_msg, mode,
                allow_tools=allow_tools, allow_image_tool=allow_image_tool, extra_input=extra_input,
            )
        return scrub_own_secrets(text), calls

    async def _run_responses_ai_impl(
        self,
        messages: list[dict],
        target_msg: discord.Message | None,
        mode: str = "fast",
        *,
        allow_tools: bool = True,
        allow_image_tool: bool = True,
        extra_input: list[dict] | None = None,
    ) -> tuple[str, list[dict]]:
        url = f"{XINGCHI_BASE_URL}/responses"
        headers = {
            "Authorization": f"Bearer {XINGCHI_API_KEY}",
            "Content-Type": "application/json",
            "User-Agent": "opencode/1.0.0",
            "X-Client-Name": "OpenCode",
        }
        effort = "high" if mode == "full" else "low"
        max_tokens = 8192 if mode == "full" else 4096
        timeout = aiohttp.ClientTimeout(total=300, sock_read=180) if mode == "full" else aiohttp.ClientTimeout(total=180, sock_read=120)

        instructions, input_items = self.to_responses_input(messages)
        tools: list[dict] = [{"type": "web_search"}]
        if allow_image_tool:
            tools.append({
                "type": "function",
                "name": "generate_image",
                "description": "Membuat gambar baru dari teks ATAU mengedit/memodifikasi gambar yang dilampirkan pengguna (seperti mengganti teks, warna, objek, aspek rasio, atau gaya). Panggil HANYA jika pengguna meminta dibuatkan atau diedit gambar.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "prompt": {
                            "type": "string",
                            "description": "Deskripsi visual gambar baru (sekitar 300-900 karakter) atau instruksi detail pengeditan gambar dalam bahasa Inggris.",
                        },
                        "use_attached_image": {
                            "type": "boolean",
                            "description": "Set true jika pengguna meminta mengedit/mengubah gambar yang dilampirkan atau baru saja dikirim; set false jika membuat gambar baru dari nol.",
                        },
                        "aspect_ratio": {
                            "type": "string",
                            "description": "Rasio aspek gambar yang diinginkan ('1:1', '16:9', '9:16', '4:3', '3:4', '3:2', '2:3', '4:5', '5:4', '21:9', atau 'auto' untuk mengikuti rasio gambar sumber saat edit / 1:1 saat buat baru).",
                        },
                    },
                    "required": ["prompt", "use_attached_image", "aspect_ratio"],
                },
            })

        if extra_input:
            for item in extra_input:
                if not isinstance(item, dict):
                    raise ValueError("Item lanjutan Responses harus berupa object.")
                item_type = item.get("type")
                if item_type == "function_call":
                    call_id = str(item.get("call_id") or "").strip()
                    name = str(item.get("name") or "").strip()
                    arguments = item.get("arguments", "{}")
                    if not call_id or not name:
                        raise ValueError("Function call lanjutan tidak memiliki call_id atau name.")
                    if not isinstance(arguments, str):
                        arguments = json.dumps(arguments, ensure_ascii=False)
                    input_items.append({
                        "type": "function_call",
                        "call_id": call_id,
                        "name": name,
                        "arguments": arguments,
                    })
                elif item_type == "function_call_output":
                    call_id = str(item.get("call_id") or "").strip()
                    if not call_id or "output" not in item:
                        raise ValueError("Function call output tidak lengkap.")
                    output = item["output"]
                    if not isinstance(output, str):
                        output = json.dumps(output, ensure_ascii=False)
                    input_items.append({
                        "type": "function_call_output",
                        "call_id": call_id,
                        "output": output,
                    })
                else:
                    raise ValueError(f"Tipe item lanjutan tidak didukung: {item_type!r}")

        payload = {
            "model": XINGCHI_MODEL,
            "instructions": instructions,
            "input": input_items,
            "tools": tools if allow_tools else [],
            "tool_choice": "auto" if allow_tools else "none",
            "reasoning": {"effort": effort},
            "max_output_tokens": max_tokens,
            "stream": True,
        }

        raw_full_text = ""
        function_calls: list[dict] = []
        response_completed = False

        def append_function_call(item: dict) -> None:
            if not isinstance(item, dict):
                raise RuntimeError("Responses mengirim function_call dengan format tidak valid.")
            call_id = str(item.get("call_id") or "").strip()
            name = str(item.get("name") or "").strip()
            if not call_id or not name:
                raise RuntimeError("Responses function_call tidak memiliki call_id atau name.")
            existing = next((fc for fc in function_calls if fc.get("call_id") == call_id), None)
            if existing is not None:
                if existing.get("name") != name or existing.get("arguments", "{}") != item.get("arguments", "{}"):
                    raise RuntimeError(f"Responses mengirim function_call duplikat dengan payload berbeda: {call_id}")
                return
            function_calls.append(item)

        last_edit = asyncio.get_event_loop().time()
        web_badge_shown = False

        async with self.http_session.post(url, headers=headers, json=payload, timeout=timeout) as resp:
            if resp.status != 200:
                err_bytes = await read_limited_stream(resp.content, 64 * 1024)
                err_text = err_bytes.decode("utf-8", errors="replace")
                raise RuntimeError(f"Responses HTTP {resp.status}: {err_text[:300]}")

            stream_bytes = 0
            while True:
                line = await resp.content.readline()
                if not line:
                    break
                stream_bytes += len(line)
                check_responses_stream_limits(len(line), stream_bytes)
                decoded = line.decode("utf-8", errors="ignore").strip()
                if not decoded.startswith("data: "):
                    continue
                data_str = decoded[6:]
                if data_str == "[DONE]":
                    break
                try:
                    event = json.loads(data_str)
                except Exception:
                    continue

                etype = event.get("type", "")

                if etype in ("response.web_search_call.in_progress", "response.web_search_call.searching") and not raw_full_text and not web_badge_shown:
                    web_badge_shown = True
                    try:
                        if target_msg is not None:
                            await target_msg.edit(content="🌐 *Sedang menelusuri web secara live...*")
                    except Exception:
                        pass

                elif etype == "response.output_text.delta":
                    delta = event.get("delta", "")
                    if delta and (raw_full_text or delta.strip()):
                        raw_full_text += delta
                        cleaned_live = clean_response_text(raw_full_text)
                        now = asyncio.get_event_loop().time()
                        if now - last_edit >= 0.8 and cleaned_live and len(cleaned_live) <= DISCORD_MSG_CHUNK_LIMIT:
                            try:
                                if target_msg is not None:
                                    await target_msg.edit(content=cleaned_live + " ▌")
                                last_edit = now
                            except Exception:
                                pass

                elif etype == "response.output_item.done":
                    item = event.get("item", {})
                    if item.get("type") == "function_call":
                        append_function_call(item)
                    elif item.get("type") == "message" and not raw_full_text:
                        for part in item.get("content", []):
                            if part.get("type") in ("output_text", "text"):
                                raw_full_text += part.get("text", "")

                elif etype == "response.completed":
                    response_completed = True
                    resp_obj = event.get("response", {})
                    for item in resp_obj.get("output", []):
                        if item.get("type") == "function_call":
                            append_function_call(item)
                        elif item.get("type") == "message" and not raw_full_text:
                            for part in item.get("content", []):
                                if part.get("type") in ("output_text", "text"):
                                    raw_full_text += part.get("text", "")

                elif etype == "response.incomplete":
                    resp_obj = event.get("response", {})
                    details = resp_obj.get("incomplete_details") or {}
                    reason = details.get("reason") or resp_obj.get("status") or "unknown"
                    raise RuntimeError(f"Responses stream incomplete: {reason}")

                elif etype in ("error", "response.failed"):
                    err_msg = event.get("error", {}).get("message") or str(event)[:250]
                    raise RuntimeError(f"Responses Stream Error: {err_msg}")

        if not response_completed:
            raise RuntimeError("Responses stream berakhir sebelum event response.completed diterima.")

        return clean_response_text(raw_full_text).strip(), function_calls

    async def process_ai_turn(
        self,
        target_channel: discord.abc.Messageable,
        guild: discord.Guild | None,
        user: discord.User | discord.Member,
        clean_content: str,
        image_data_urls: list[str],
        llm_image_urls: list[str] | None = None,
        additional_file_text: str = "",
        reply_to_message: discord.Message | None = None,
    ):
        # Sensor secret yang diketik langsung di chat sebelum masuk prompt/memori.
        # (Teks lampiran sudah dipindai di encode_attachment.)
        clean_content = scrub_secrets(clean_content or "")
        channel_id = getattr(target_channel, "id", 0)
        guild_id = guild.id if guild is not None else 0
        scope_key = self.get_scope_key(guild, user.id, channel_id)
        http_img_urls = [u for u in (llm_image_urls or []) if u.startswith(("http://", "https://"))]
        current_turn_images: list[str] = []
        for u in (image_data_urls or []) + http_img_urls:
            if isinstance(u, str) and u.startswith(("http://", "https://", "data:image/")) and u not in current_turn_images:
                current_turn_images.append(u)
                if len(current_turn_images) >= MAX_VISION_IMAGES_PER_TURN:
                    break

        allow_img_tool = should_allow_image_tool(
            clean_content,
            has_file_or_pdf=bool(additional_file_text),
            has_image=bool(current_turn_images),
        )

        async with self.guild_locks[scope_key]:
            guild_state = self.get_guild_state(guild, user.id, channel_id)
            mode = guild_state["thread_modes"].get(str(target_channel.id), "fast")
            history_msgs = guild_state["messages"]

            if image_data_urls and channel_id:
                self.set_last_user_image(guild_id, channel_id, user.id, image_data_urls)

            full_user_prompt = clean_content
            if additional_file_text:
                full_user_prompt += f"\n\n{additional_file_text}\n(Tolong baca dan analisis file serta gambar yang disertakan di atas!)"

            user_display_text = f"{user.display_name}: {full_user_prompt}"

            if http_img_urls:
                blocks = [{"type": "text", "text": user_display_text}] + [
                    {"type": "image_url", "image_url": {"url": u}} for u in http_img_urls[:MAX_VISION_IMAGES_PER_TURN]
                ]
                history_msgs.append({"role": "user", "content": blocks})
            else:
                history_msgs.append({"role": "user", "content": user_display_text})

            for m in history_msgs[:-1]:
                if isinstance(m.get("content"), list):
                    text_parts = []
                    for block in m["content"]:
                        if block.get("type") == "text":
                            text_parts.append(block.get("text", ""))
                        elif block.get("type") == "image_url":
                            text_parts.append("[Gambar]")
                    m["content"] = "\n".join(text_parts).strip() or "[Gambar]"

            if len(history_msgs) > MAX_RECENT_MESSAGES:
                guild_state["messages"] = history_msgs[-MAX_RECENT_MESSAGES:]
                history_msgs = guild_state["messages"]

            payload_messages = self.build_messages_payload(
                guild, user.id, channel_id, current_turn_images=current_turn_images
            )

            if additional_file_text or current_turn_images:
                status_badge = "🔍 *Sedang membaca dan menganalisis file...*"
            elif mode == "full":
                status_badge = "🧠 *Sedang berpikir mendalam untuk menyusun jawaban...*"
            else:
                status_badge = "💬 *Sedang memproses pesan...*"

            status_msg = await (
                reply_to_message.reply(status_badge, mention_author=False)
                if reply_to_message
                else target_channel.send(status_badge)
            )

            try:
                reply_text, function_calls = await self.run_responses_ai(
                    payload_messages,
                    status_msg,
                    mode=mode,
                    allow_tools=True,
                    allow_image_tool=allow_img_tool,
                )

                img_calls = [fc for fc in function_calls if fc.get("name") == "generate_image"]
                unsupported_calls = [fc for fc in function_calls if fc.get("name") != "generate_image"]
                if unsupported_calls:
                    rejected_items = build_failure_tool_continuation(
                        function_calls,
                        "Function tool tidak didukung oleh bot ini. Tool yang tersedia hanya generate_image; web_search ditangani provider.",
                    )
                    if rejected_items:
                        try:
                            follow_text, _ = await self.run_responses_ai(
                                payload_messages,
                                status_msg,
                                mode=mode,
                                allow_tools=False,
                                allow_image_tool=False,
                                extra_input=rejected_items,
                            )
                            if follow_text:
                                reply_text = follow_text
                        except Exception as exc:
                            logging.exception("Continuation unsupported tool gagal (%s)", scope_key)
                            reply_text = f"⚠️ Tool dari model tidak didukung dan kelanjutan gagal: {type(exc).__name__}."
                    function_calls = []
                    img_calls = []

                image_block_reason = None
                image_rate_wait = 0.0
                if img_calls and not allow_img_tool:
                    image_block_reason = "Pengguna hanya meminta analisis/penjelasan, bukan pembuatan atau pengeditan gambar."
                elif img_calls:
                    img_allowed, image_rate_wait = self.rate_limiter.acquire("image", user.id)
                    if not img_allowed:
                        image_block_reason = (
                            "Batas pemakaian pembuatan/edit gambar untuk pengguna ini sudah tercapai. "
                            f"Jelaskan singkat bahwa gambar bisa dibuat lagi sekitar {format_wait(image_rate_wait)} lagi."
                        )
                if image_block_reason:
                    blocked_items = build_failure_tool_continuation(img_calls, image_block_reason)
                    if blocked_items:
                        try:
                            blocked_text, _ = await self.run_responses_ai(
                                payload_messages,
                                status_msg,
                                mode=mode,
                                allow_tools=False,
                                allow_image_tool=False,
                                extra_input=blocked_items,
                            )
                            if blocked_text:
                                reply_text = blocked_text
                        except Exception:
                            logging.exception("Continuation blocked image call gagal (%s)", scope_key)
                    if image_rate_wait and not reply_text:
                        reply_text = f"⏳ Batas pembuatan/edit gambar tercapai. Coba lagi sekitar {format_wait(image_rate_wait)}."
                    img_calls = []

                if img_calls:
                    if self.is_user_image_busy(user.id):
                        await status_msg.edit(content="⏳ *Menunggu antrean proses gambar sebelumnya selesai...*")

                    async with self.user_image_queue(user.id):
                        unresolved_img_calls = list(img_calls)
                        is_edit = False
                        try:
                            primary_call = img_calls[0]
                            extra_calls = img_calls[1:]

                            try:
                                args_dict = json.loads(primary_call.get("arguments", "{}"))
                            except Exception:
                                args_dict = {}

                            img_prompt = (args_dict.get("prompt") or clean_content).strip()
                            use_attached = bool(args_dict.get("use_attached_image", False))
                            req_ratio = args_dict.get("aspect_ratio") or extract_aspect_ratio_from_text(clean_content)

                            replied_imgs: list[str] = []
                            if reply_to_message is not None:
                                replied_imgs, _ = await self.resolve_replied_images(reply_to_message)

                            wants_edit = use_attached or any(w in clean_content.lower() for w in EDIT_INTENT_KEYWORDS)

                            source_imgs: list[str] | None = None
                            if use_attached:
                                source_imgs = (
                                    image_data_urls
                                    or replied_imgs
                                    or self.get_last_user_image(guild_id, channel_id, user.id)
                                )
                            elif image_data_urls or replied_imgs:
                                if wants_edit:
                                    source_imgs = image_data_urls or replied_imgs
                            elif wants_edit:
                                source_imgs = self.get_last_user_image(guild_id, channel_id, user.id)

                            if wants_edit and not source_imgs:
                                fail_items = build_failure_tool_continuation(
                                    unresolved_img_calls,
                                    "Gambar sumber untuk edit gambar tidak ditemukan.",
                                )
                                unresolved_img_calls = []
                                if fail_items:
                                    try:
                                        await self.run_responses_ai(
                                            payload_messages,
                                            status_msg,
                                            mode=mode,
                                            allow_tools=False,
                                            allow_image_tool=False,
                                            extra_input=fail_items,
                                        )
                                    except Exception:
                                        logging.exception("Continuation missing source image gagal (%s)", scope_key)
                                fail_msg = (
                                    "⚠️ Gagal memproses edit gambar: tidak ada gambar sumber yang ditemukan "
                                    "(lampirkan gambar, *reply* ke pesan bergambar, atau pastikan konteks gambar sebelumnya masih tersedia)."
                                )
                                history_msgs.append({"role": "assistant", "content": fail_msg})
                                guild_state["turn_count"] = guild_state.get("turn_count", 0) + 1
                                await self.save_memory()
                                await status_msg.edit(content=fail_msg[:1990])
                                return

                            is_edit = bool(source_imgs)
                            action_badge = "🖌️ *Sedang mengedit gambar...*" if is_edit else "🎨 *Sedang membuat gambar...*"
                            await status_msg.edit(content=action_badge)

                            img_bytes, out_filename, out_mime, engine_used = await self.generate_or_edit_image(
                                img_prompt, source_images=source_imgs, aspect_ratio=req_ratio
                            )

                            continuation_items: list[dict] = []
                            p_call_id = primary_call.get("call_id")
                            if p_call_id:
                                continuation_items.append(primary_call)
                                continuation_items.append({
                                    "type": "function_call_output",
                                    "call_id": p_call_id,
                                    "output": json.dumps({
                                        "success": True,
                                        "operation": "edit_image" if is_edit else "generate_image",
                                        "engine": engine_used,
                                        "filename": out_filename,
                                        "detail": "Gambar berhasil dibuat dan dilampirkan ke pesan Discord."
                                    }, ensure_ascii=False),
                                })

                            for extra_fc in extra_calls:
                                e_call_id = extra_fc.get("call_id")
                                if e_call_id:
                                    continuation_items.append(extra_fc)
                                    continuation_items.append({
                                        "type": "function_call_output",
                                        "call_id": e_call_id,
                                        "output": json.dumps({
                                            "success": False,
                                            "skipped": True,
                                            "reason": "Hanya satu panggilan gambar utama yang diproses per giliran."
                                        }, ensure_ascii=False),
                                    })

                            unresolved_img_calls = []
                            if continuation_items:
                                try:
                                    final_text, _ = await self.run_responses_ai(
                                        payload_messages,
                                        status_msg,
                                        mode=mode,
                                        allow_tools=False,
                                        allow_image_tool=False,
                                        extra_input=continuation_items,
                                    )
                                    if final_text:
                                        reply_text = final_text
                                except Exception as follow_exc:
                                    logging.exception("Continuation sukses gambar gagal (%s)", scope_key)
                                    reply_text = (reply_text + f"\n\nGambar berhasil diproses. (Catatan: model tidak menyelesaikan respons lanjutan: {safe_exc_text(follow_exc)})").strip()

                            if channel_id:
                                context_image = await asyncio.to_thread(
                                    self._compress_image_bytes_to_data_url, img_bytes
                                )
                                self.set_last_user_image(guild_id, channel_id, user.id, [context_image])

                            file = discord.File(fp=io.BytesIO(img_bytes), filename=out_filename)

                            embed_title = "🖌️ Clouzer AI Image Editor" if is_edit else "🎨 Clouzer AI Image Generator"
                            embed_desc = f"**Prompt:** {img_prompt[:3600]}"
                            if is_edit:
                                embed_desc = f"{embed_desc[:3450]}\n\n{TEXT_EDIT_NOTE}"

                            embed = discord.Embed(
                                title=embed_title,
                                description=embed_desc,
                                color=discord.Color.blurple(),
                            )
                            embed.set_image(url=f"attachment://{out_filename}")
                            embed.set_footer(text=f"Created by clouzerd | API: {engine_used}")

                            extra_note = f"\n\n{TEXT_EDIT_NOTE}" if is_edit else ""
                            combined_text = f"{reply_text}{extra_note}".strip() if reply_text else (TEXT_EDIT_NOTE if is_edit else "")
                            caption_chunks = split_discord_chunks(combined_text, limit=DISCORD_MSG_CHUNK_LIMIT) if combined_text else []
                            first_caption = caption_chunks[0] if caption_chunks else None

                            mem_summary = format_memory_image_summary(engine_used, img_prompt)
                            mem_content = f"{reply_text}\n{mem_summary}".strip() if reply_text else mem_summary
                            history_msgs.append({"role": "assistant", "content": mem_content})
                            guild_state["turn_count"] = guild_state.get("turn_count", 0) + 1
                            await self.save_memory()

                            await status_msg.edit(content=first_caption, embed=embed, attachments=[file])
                            for extra_chunk in caption_chunks[1:]:
                                await target_channel.send(extra_chunk)
                            return
                        except Exception as img_exc:
                            if unresolved_img_calls:
                                fail_items = build_failure_tool_continuation(
                                    unresolved_img_calls,
                                    f"Proses gambar gagal: {safe_exc_text(img_exc)}",
                                )
                                unresolved_img_calls = []
                                if fail_items:
                                    try:
                                        await self.run_responses_ai(
                                            payload_messages,
                                            status_msg,
                                            mode=mode,
                                            allow_tools=False,
                                            allow_image_tool=False,
                                            extra_input=fail_items,
                                        )
                                    except Exception:
                                        logging.exception("Continuation exception gambar gagal (%s)", scope_key)
                            if is_edit:
                                fail_msg = (
                                    f"⚠️ Edit gambar gagal dilakukan ({safe_exc_text(img_exc)}). "
                                    f"Gambar tidak diubah dan tidak dialihkan ke generator gambar baru."
                                )[:1990]
                                history_msgs.append({"role": "assistant", "content": fail_msg})
                                guild_state["turn_count"] = guild_state.get("turn_count", 0) + 1
                                await self.save_memory()
                                await status_msg.edit(content=fail_msg)
                                return
                            raise

                reply_text = reply_text or "Maaf, tidak ada respon."
                history_msgs.append({"role": "assistant", "content": reply_text})
                guild_state["turn_count"] = guild_state.get("turn_count", 0) + 1
                await self.save_memory()

                # State tombol disimpan di ViewStateStore (dibatasi + persisten), bukan di objek view.
                # Kegagalan menyimpan state tidak boleh menggagalkan jawaban: tombol saja yang jadi kedaluwarsa.
                try:
                    self.view_states.put(
                        status_msg.id,
                        owner_id=user.id,
                        messages=[m for m in payload_messages if m.get("role") != "system"],
                        mode=mode,
                        allow_image_tool=allow_img_tool,
                        user_prompt_text=clean_content,
                        source_images=image_data_urls,
                    )
                    await self.view_states.save()
                except Exception:
                    logging.exception("Gagal menyimpan state tombol (%s)", scope_key)
                ui_view = self.get_response_view()
                chunks = split_discord_chunks(reply_text, limit=DISCORD_MSG_CHUNK_LIMIT)
                await status_msg.edit(content=chunks[0], view=ui_view)
                for chunk in chunks[1:]:
                    await target_channel.send(chunk)
            except Exception as e:
                if history_msgs:
                    history_msgs.pop()
                err_msg = f"⚠️ Error: `{safe_exc_text(e)}`"[:1990]
                await status_msg.edit(content=err_msg)


bot = ClouzerBot()


def get_permission_warning(guild: discord.Guild | None) -> str:
    if not bot.has_any_allowed_channel(guild):
        return "⚠️ **Setup Awal:** Bot belum diizinkan. Admin ketik `/channel` → **Izinkan Channel Ini**!"
    return "❌ Channel ini belum diizinkan. Atur lewat `/channel`."


@bot.tree.command(name="channel", description="Atur izin channel bot (Khusus Admin)")
@app_commands.describe(aksi="Pilih tindakan", target="Channel tujuan")
@app_commands.choices(
    aksi=[
        app_commands.Choice(name="Izinkan Channel Ini", value="izinkan"),
        app_commands.Choice(name="Tolak / Hapus Izin Channel", value="tolak"),
        app_commands.Choice(name="Lihat Daftar Channel Diizinkan", value="list"),
    ]
)
@app_commands.default_permissions(manage_channels=True)
async def channel_perm_cmd(interaction: discord.Interaction, aksi: app_commands.Choice[str], target: discord.TextChannel | None = None):
    if interaction.guild is None:
        await interaction.response.send_message("Perintah khusus server.", ephemeral=True)
        return
    member_perms = getattr(interaction.user, "guild_permissions", None)
    if not member_perms or not (member_perms.manage_channels or member_perms.administrator):
        await interaction.response.send_message(
            "⛔ Perintah ini hanya untuk admin dengan izin Manage Channels.", ephemeral=True
        )
        return

    await interaction.response.defer(ephemeral=True)
    guild_state = bot.get_guild_state(interaction.guild)

    if aksi.value == "list":
        allowed_ids = [cid for cid in guild_state["allowed_channels"] if interaction.guild.get_channel(cid) is not None]
        if not allowed_ids:
            await interaction.followup.send("📋 Belum ada channel diizinkan.", ephemeral=True)
        else:
            mentions = "\n".join(f"• <#{cid}>" for cid in allowed_ids)
            await interaction.followup.send(f"📋 **Channel Diizinkan:**\n{mentions}", ephemeral=True)
        return

    ch = target or (interaction.channel.parent if isinstance(interaction.channel, discord.Thread) else interaction.channel)
    if aksi.value == "izinkan":
        if ch.id not in guild_state["allowed_channels"]:
            guild_state["allowed_channels"].append(ch.id)
            await bot.save_memory()
        await interaction.followup.send(f"✅ Izin diberikan di {ch.mention}!", ephemeral=True)
    elif aksi.value == "tolak":
        if ch.id in guild_state["allowed_channels"]:
            guild_state["allowed_channels"].remove(ch.id)
            await bot.save_memory()
        await interaction.followup.send(f"🚫 Izin dicabut di {ch.mention}!", ephemeral=True)


async def handle_mode_command(interaction: discord.Interaction, mode: str, prompt: str | None):
    if not bot.is_channel_allowed(interaction.channel, interaction.guild):
        await interaction.response.send_message(get_permission_warning(interaction.guild), ephemeral=True)
        return

    if prompt and prompt.strip():  # hanya yang benar-benar memanggil AI yang kena rate limit
        allowed, wait = bot.rate_limiter.acquire("chat", interaction.user.id)
        if not allowed:
            await interaction.response.send_message(rate_limit_text(wait), ephemeral=True)
            return
        prompt = scrub_secrets(prompt)  # echo prompt ke channel juga tidak boleh membawa secret

    await interaction.response.defer(thinking=True)
    mode_badge = "🧠 **[Full Thinking]**" if mode == "full" else "⚡ **[Fast Mode]**"
    ch_id = getattr(interaction.channel, "id", 0)
    guild_state = bot.get_guild_state(interaction.guild, interaction.user.id, ch_id)
    channel = interaction.channel

    if interaction.guild is not None and not isinstance(channel, discord.Thread) and isinstance(channel, discord.TextChannel):
        thread_title = f"GPT 6.1 SOL | {interaction.user.display_name}"[:100]
        try:
            thread = await channel.create_thread(name=thread_title, type=discord.ChannelType.public_thread, auto_archive_duration=1440)
            if thread.id not in guild_state["active_threads"]:
                guild_state["active_threads"].append(thread.id)
            bot.get_guild_state(interaction.guild, interaction.user.id, thread.id)["thread_modes"][str(thread.id)] = mode
            await bot.save_memory()

            await interaction.followup.send(f"{mode_badge} Thread baru dibuat: {thread.mention}")
            if prompt and prompt.strip():
                await thread.send(f"{mode_badge} **{interaction.user.display_name}:** {prompt.strip()}")
                await bot.process_ai_turn(target_channel=thread, guild=interaction.guild, user=interaction.user, clean_content=prompt.strip(), image_data_urls=[])
            return
        except Exception:
            pass

    guild_state["thread_modes"][str(channel.id)] = mode
    await bot.save_memory()

    if prompt and prompt.strip():
        await interaction.followup.send(f"{mode_badge} **{interaction.user.display_name}:** {prompt.strip()}")
        await bot.process_ai_turn(target_channel=channel, guild=interaction.guild, user=interaction.user, clean_content=prompt.strip(), image_data_urls=[])
    else:
        await interaction.followup.send(f"{mode_badge} Mode diubah ke **{mode.upper()}**.")


@bot.tree.command(name="fast", description="Chat dengan mode cepat (/fast)")
async def fast_cmd(interaction: discord.Interaction, prompt: str | None = None):
    await handle_mode_command(interaction, mode="fast", prompt=prompt)


@bot.tree.command(name="full-thinking", description="Chat dengan mode berpikir mendalam (/full-thinking)")
async def full_thinking_cmd(interaction: discord.Interaction, prompt: str | None = None):
    await handle_mode_command(interaction, mode="full", prompt=prompt)


@bot.tree.command(name="summarize", description="Ringkas obrolan terbaru di channel ini")
@app_commands.describe(limit="Jumlah pesan terakhir yang ingin dirangkum (default: 30)")
async def summarize_cmd(interaction: discord.Interaction, limit: int = 30):
    if not bot.is_channel_allowed(interaction.channel, interaction.guild):
        await interaction.response.send_message(get_permission_warning(interaction.guild), ephemeral=True)
        return

    allowed, wait = bot.rate_limiter.acquire("summarize", interaction.user.id)
    if not allowed:
        await interaction.response.send_message(rate_limit_text(wait), ephemeral=True)
        return

    await interaction.response.defer(thinking=True)
    scope_key = bot.get_scope_key(
        interaction.guild, interaction.user.id, interaction.channel_id
    )
    try:
        async with bot.guild_locks[scope_key]:
            messages_text = []
            async for msg in interaction.channel.history(limit=min(max(limit, 1), 100)):
                if not msg.author.bot and msg.content.strip():
                    messages_text.append(f"{msg.author.display_name}: {scrub_secrets(msg.content)}")

            if not messages_text:
                await interaction.followup.send("⚠️ Tidak ada pesan teks yang bisa dirangkum di channel ini.")
                return

            chat_snippet = "\n".join(reversed(messages_text))
            sum_prompt = (
                "Tolong buatkan ringkasan singkat, padat, dan jelas dari percakapan obrolan Discord berikut ini. "
                "Sebutkan poin-poin penting atau topik yang sedang dibahas oleh member:\n\n"
                f"{chat_snippet}"
            )

            summary_result, _ = await bot.run_responses_ai(
                [{"role": "user", "content": sum_prompt}], None, "fast", allow_tools=False, allow_image_tool=False
            )
        await interaction.followup.send(
            f"📋 **Ringkasan Obrolan Channel ({len(messages_text)} pesan terakhir):**\n\n{(summary_result or 'Tidak ada ringkasan.')[:DISCORD_MSG_CHUNK_LIMIT]}"
        )
    except Exception:
        logging.exception("Summarize gagal untuk scope %s", scope_key)
        await interaction.followup.send("⚠️ Gagal merangkum obrolan. Cek log bot untuk detail error.")


@bot.tree.command(name="imagine", description="Buat gambar baru atau edit gambar menggunakan Cloudflare AI (+ Backup FLUX)")
@app_commands.describe(
    prompt="Deskripsi gambar baru atau instruksi edit (disarankan bahasa Inggris)",
    gambar="Opsional: Lampirkan gambar jika ingin diedit",
    rasio="Opsional: Pilih rasio aspek gambar (default Auto)",
)
@app_commands.choices(
    rasio=[
        app_commands.Choice(name="Auto (Ikuti Gambar Asli / 1:1)", value="auto"),
        app_commands.Choice(name="16:9 (Landscape / Widescreen)", value="16:9"),
        app_commands.Choice(name="9:16 (Portrait / Story)", value="9:16"),
        app_commands.Choice(name="4:3 (Standar Landscape)", value="4:3"),
        app_commands.Choice(name="3:4 (Standar Portrait)", value="3:4"),
        app_commands.Choice(name="3:2 (Foto Landscape)", value="3:2"),
        app_commands.Choice(name="2:3 (Foto Portrait)", value="2:3"),
        app_commands.Choice(name="4:5 (Feed Portrait)", value="4:5"),
        app_commands.Choice(name="5:4 (Feed Landscape)", value="5:4"),
        app_commands.Choice(name="21:9 (Ultrawide)", value="21:9"),
        app_commands.Choice(name="1:1 (Persegi / Square)", value="1:1"),
    ]
)
async def imagine_cmd(
    interaction: discord.Interaction,
    prompt: str,
    gambar: discord.Attachment | None = None,
    rasio: app_commands.Choice[str] | None = None,):
    if not bot.is_channel_allowed(interaction.channel, interaction.guild):
        await interaction.response.send_message(get_permission_warning(interaction.guild), ephemeral=True)
        return

    allowed, wait = bot.rate_limiter.acquire("image", interaction.user.id)
    if not allowed:
        await interaction.response.send_message(rate_limit_text(wait), ephemeral=True)
        return
    prompt = scrub_secrets(prompt or "")

    ch_id = getattr(interaction.channel, "id", 0)
    g_id = interaction.guild.id if interaction.guild is not None else 0
    scope_key = bot.get_scope_key(interaction.guild, interaction.user.id, ch_id)
    selected_ratio = rasio.value if rasio is not None else None
    was_busy = bot.is_user_image_busy(interaction.user.id)

    initial_status = (
        "⏳ *Menunggu antrean proses gambar sebelumnya selesai...*"
        if was_busy
        else "💬 *Sedang memproses pesan...*"
    )
    await interaction.response.send_message(initial_status)

    try:
        async with bot.guild_locks[scope_key]:
            async with bot.user_image_queue(interaction.user.id):
                source_imgs: list[str] | None = None
                if gambar is not None:
                    _, imgs_res, _, ftype = await bot.encode_attachment(gambar)
                    if ftype != "image" or not imgs_res:
                        await interaction.edit_original_response(content="⚠️ Lampiran harus berupa file gambar valid (`.png`, `.jpg`, `.jpeg`, `.webp`).")
                        return
                    source_imgs = imgs_res

                is_edit = bool(source_imgs)
                action_badge = "🖌️ *Sedang mengedit gambar...*" if is_edit else "🎨 *Sedang membuat gambar...*"
                await interaction.edit_original_response(content=action_badge)

                try:
                    img_bytes, out_filename, out_mime, engine_used = await bot.generate_or_edit_image(
                        prompt, source_images=source_imgs, aspect_ratio=selected_ratio
                    )
                except Exception as img_exc:
                    if is_edit:
                        await interaction.edit_original_response(
                            content=(
                                f"⚠️ Edit gambar gagal dilakukan ({safe_exc_text(img_exc)}). "
                                f"Gambar tidak diubah dan tidak dialihkan ke generator gambar baru."
                            )[:1990]
                        )
                        return
                    raise

                if ch_id:
                    context_image = await asyncio.to_thread(
                        bot._compress_image_bytes_to_data_url, img_bytes
                    )
                    bot.set_last_user_image(g_id, ch_id, interaction.user.id, [context_image])

                file = discord.File(fp=io.BytesIO(img_bytes), filename=out_filename)

                embed_title = "🖌️ Clouzer AI Image Editor" if is_edit else "🎨 Clouzer AI Image Generator"
                embed_desc = f"**Prompt:** {prompt.strip()[:3600]}"
                if is_edit:
                    embed_desc = f"{embed_desc[:3450]}\n\n{TEXT_EDIT_NOTE}"

                embed = discord.Embed(
                    title=embed_title,
                    description=embed_desc,
                    color=discord.Color.blurple(),
                )
                embed.set_image(url=f"attachment://{out_filename}")
                embed.set_footer(text=f"Created by clouzerd | API: {engine_used}")

                await interaction.edit_original_response(content=None, embed=embed, attachments=[file])
    except Exception as e:
        try:
            err_txt = f"⚠️ Terjadi kesalahan saat memproses gambar: `{safe_exc_text(e)}`"[:1990]
            if interaction.response.is_done():
                await interaction.edit_original_response(content=err_txt)
            else:
                await interaction.response.send_message(err_txt, ephemeral=True)
        except Exception:
            pass


@bot.tree.command(name="cek-tool", description="Tes diagnostik Function Calling & Built-in Web Search (/responses)")
async def cek_tool_cmd(interaction: discord.Interaction):
    if not bot.is_channel_allowed(interaction.channel, interaction.guild):
        await interaction.response.send_message(get_permission_warning(interaction.guild), ephemeral=True)
        return

    if DIAGNOSTIC_ADMIN_ONLY:
        perms = getattr(interaction.user, "guild_permissions", None)
        if interaction.guild is None or not perms or not (perms.manage_guild or perms.administrator):
            await interaction.response.send_message(
                "⛔ Perintah diagnostik ini hanya untuk admin server (izin Manage Server).", ephemeral=True
            )
            return

    allowed, wait = bot.rate_limiter.acquire("diagnostic", interaction.user.id)
    if not allowed:
        await interaction.response.send_message(rate_limit_text(wait), ephemeral=True)
        return

    await interaction.response.defer(thinking=True)

    url = f"{XINGCHI_BASE_URL}/responses"
    headers = {
        "Authorization": f"Bearer {XINGCHI_API_KEY}",
        "Content-Type": "application/json",
        "User-Agent": "opencode/1.0.0",
        "X-Client-Name": "OpenCode",
    }

    async def run_probe(payload: dict) -> tuple[int, dict | None, str]:
        try:
            async with bot.http_session.post(
                url,
                headers=headers,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=60),
            ) as resp:
                raw = await resp.text()
                try:
                    return resp.status, json.loads(raw), raw
                except Exception:
                    return resp.status, None, raw
        except Exception as exc:
            return 0, None, f"{type(exc).__name__}: {exc}"

    payload_fc = {
        "model": XINGCHI_MODEL,
        "input": "Panggil fungsi cek_status_server dengan target 'wispbyte' sekarang juga tanpa teks tambahan.",
        "tools": [
            {
                "type": "function",
                "name": "cek_status_server",
                "description": "Mengecek status server bot Discord",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "target": {"type": "string", "description": "Nama server"}
                    },
                    "required": ["target"],
                },
            }
        ],
        "tool_choice": "auto",
        "stream": False,
    }

    payload_ws = {
        "model": XINGCHI_MODEL,
        "input": "Cari di web harga terbaru kurs 1 USD ke Rupiah hari ini dan sebutkan sumbernya.",
        "tools": [{"type": "web_search"}],
        "stream": False,
    }

    status_fc, data_fc, raw_fc = await run_probe(payload_fc)
    status_ws, data_ws, raw_ws = await run_probe(payload_ws)
    raw_fc = scrub_secrets(raw_fc)
    raw_ws = scrub_secrets(raw_ws)

    if status_fc == 200 and isinstance(data_fc, dict):
        outputs_fc = data_fc.get("output", [])
        types_fc = [item.get("type", "unknown") for item in outputs_fc]
        fn_calls = [item for item in outputs_fc if item.get("type") == "function_call"]
        if fn_calls:
            call_info = f"`{fn_calls[0].get('name')}` args: `{fn_calls[0].get('arguments')}`"
            fc_report = f"✅ **AKTIF (HTTP 200)**\nOutput types: `{types_fc}`\nCall: {call_info}"
        else:
            fc_report = f"⚠️ **HTTP 200 (Tool Diabaikan)**\nOutput types: `{types_fc}`\nSnippet: ```json\n{raw_fc[:450]}\n```"
    else:
        fc_report = f"❌ **GAGAL (HTTP {status_fc})**\n```json\n{raw_fc[:500]}\n```"

    if status_ws == 200 and isinstance(data_ws, dict):
        outputs_ws = data_ws.get("output", [])
        types_ws = [item.get("type", "unknown") for item in outputs_ws]
        has_ws_call = any("web_search" in t for t in types_ws)
        text_preview = ""
        for item in outputs_ws:
            if item.get("type") == "message":
                for part in item.get("content", []):
                    if part.get("type") in ("output_text", "text"):
                        text_preview += part.get("text", "")
        text_preview = clean_response_text(text_preview)
        if has_ws_call:
            ws_report = f"✅ **AKTIF (HTTP 200)**\nOutput types: `{types_ws}`\nHasil: {text_preview[:450]}"
        else:
            ws_report = f"⚠️ **HTTP 200 (Web Search Diabaikan)**\nOutput types: `{types_ws}`\nTeks: {text_preview[:400] or raw_ws[:400]}"
    else:
        ws_report = f"❌ **GAGAL (HTTP {status_ws})**\n```json\n{raw_ws[:500]}\n```"

    cf_status = f"Terpasang ({len(CF_ACCOUNTS)} akun)" if CF_ACCOUNTS else "Kosong"
    embed = discord.Embed(
        title="🧪 Hasil Diagnostik Tool & Web Search (/v1/responses)",
        description=f"Model: `{XINGCHI_MODEL}` | Cloudflare AI: `{cf_status}` | Gen: `{CF_IMAGE_MODEL.split('/')[-1]}` | Edit: `{CF_EDIT_MODEL.split('/')[-1]}`",
        color=discord.Color.gold(),
    )
    embed.add_field(name="1️⃣ Custom Function Calling", value=fc_report[:1020], inline=False)
    embed.add_field(name="2️⃣ Built-in Web Search", value=ws_report[:1020], inline=False)
    await interaction.followup.send(embed=embed)


@bot.event
async def on_ready():
    bot.schedule_command_sync()
    print(f"[ONLINE] Clouzer AI Bot aktif (Cloudflare AI: {'OK (' + str(len(CF_ACCOUNTS)) + ' akun)' if CF_ACCOUNTS else 'MISSING'} | Gen: {CF_IMAGE_MODEL} | Edit: {CF_EDIT_MODEL} | Audio: {CF_AUDIO_MODEL} | Multi-Format Doc/Slide/Sheet/Design/Audio Reader + Native Web Search)!")
    print("[CHECK] Pastikan Message Content Intent juga aktif di Discord Developer Portal.")


async def notify_rate_limited(message: discord.Message, wait: float) -> None:
    """Beri tahu pengguna sekali saja per ~30 detik (selebihnya diam) supaya spam tidak memicu spam balasan."""
    if not bot.rate_limiter.should_notify(message.author.id):
        return
    try:
        await message.reply(rate_limit_text(wait), mention_author=False, delete_after=10)
    except Exception:
        logging.debug("Gagal mengirim notifikasi rate limit", exc_info=True)


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return
    if not bot.is_channel_allowed(message.channel, message.guild):
        return

    clean_content = message.content.replace(f"<@{bot.user.id}>", "").replace(f"<@!{bot.user.id}>", "").strip()

    # Pesan tanpa teks, lampiran, maupun reply tidak akan memicu AI: jangan habiskan jatah rate limit.
    if not clean_content and not message.attachments and message.reference is None:
        return

    allowed, wait = bot.rate_limiter.acquire("chat", message.author.id)
    if not allowed:
        await notify_rate_limited(message, wait)
        return
    if message.attachments:
        allowed, wait = bot.rate_limiter.acquire("file", message.author.id, counts_daily=False)
        if not allowed:
            await notify_rate_limited(message, wait)
            return

    image_data_urls: list[str] = []
    llm_image_urls: list[str] = []
    additional_file_text = ""
    blocked_files: list[str] = []
    skipped_notes: list[str] = []
    has_usable_attachment = False

    attachments = list(message.attachments)
    if len(attachments) > MAX_ATTACHMENTS_PER_MESSAGE:
        skipped_notes.append(
            f"{len(attachments) - MAX_ATTACHMENTS_PER_MESSAGE} lampiran dilewati (maksimal {MAX_ATTACHMENTS_PER_MESSAGE} per pesan)"
        )
        attachments = attachments[:MAX_ATTACHMENTS_PER_MESSAGE]

    total_bytes = 0
    for att in attachments:
        att_size = max(int(getattr(att, "size", 0) or 0), 0)
        if total_bytes + att_size > MAX_ATTACHMENT_TOTAL_BYTES:
            skipped_notes.append(
                f"`{scrub_secrets(att.filename)[:60]}` dilewati (total ukuran lampiran melewati "
                f"{MAX_ATTACHMENT_TOTAL_BYTES // (1024 * 1024)} MB)"
            )
            continue
        total_bytes += att_size

        text_res, local_res, http_res, ftype = await bot.encode_attachment(att)
        if ftype == "blocked":
            blocked_files.append(scrub_secrets(att.filename)[:60])
        elif ftype not in ("none", "busy") and (text_res or local_res or http_res):
            has_usable_attachment = True
        if text_res:
            additional_file_text += text_res
        if local_res:
            image_data_urls.extend(local_res)
        if http_res:
            llm_image_urls.extend(http_res)

    notices: list[str] = []
    if blocked_files:
        names = ", ".join(f"`{n}`" for n in blocked_files)
        notices.append(
            f"🔒 Lampiran {names} tidak dibaca karena terdeteksi sebagai file kredensial/rahasia "
            f"(token, password, private key, atau file .env). Isinya tidak dikirim ke AI dan tidak disimpan. "
            f"Hapus bagian rahasianya lalu kirim ulang kalau mau dibantu."
        )
    if skipped_notes:
        notices.append("📎 " + "; ".join(skipped_notes) + ".")
    if notices:
        try:
            await message.reply("\n".join(notices)[:1900], mention_author=False)
        except Exception:
            logging.debug("Gagal mengirim notifikasi lampiran", exc_info=True)

    if not image_data_urls and message.reference is not None:
        rep_local, rep_http = await bot.resolve_replied_images(message)
        if rep_local:
            image_data_urls.extend(rep_local)
        if rep_http:
            llm_image_urls.extend(rep_http)

    if not clean_content:
        if has_usable_attachment and additional_file_text:
            clean_content = "Tolong baca, analisis, dan ringkas isi file yang saya kirim ini ya."
        elif image_data_urls or llm_image_urls:
            clean_content = "Tolong jelaskan isi gambar ini."
        else:
            return

    await bot.process_ai_turn(
        target_channel=message.channel,
        guild=message.guild,
        user=message.author,
        clean_content=clean_content,
        image_data_urls=image_data_urls,
        llm_image_urls=llm_image_urls,
        additional_file_text=additional_file_text,
        reply_to_message=message,
    )


async def main():
    # Log hanya WARNING+ secara default (sama seperti sebelumnya); ubah lewat LOG_LEVEL.
    logging.basicConfig(
        level=getattr(logging, os.getenv("LOG_LEVEL", "WARNING").strip().upper(), logging.WARNING),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    install_log_redaction()  # token/API key tidak boleh bocor ke konsol hosting
    if not DISCORD_TOKEN or not XINGCHI_API_KEY:
        raise RuntimeError("Token belum lengkap di .env!")
    for config_warning in check_runtime_config():
        logging.warning(config_warning)
    async with bot:
        await bot.start(DISCORD_TOKEN)


if __name__ == "__main__":
    asyncio.run(main())